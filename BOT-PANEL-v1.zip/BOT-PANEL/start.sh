#!/usr/bin/env bash
set -e
. .venv/bin/activate
exec python -m uvicorn app:app --host 0.0.0.0 --port "${PORT:-8080}"
