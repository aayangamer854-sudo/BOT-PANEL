#!/usr/bin/env bash
set -e
. .venv/bin/activate
pip install -r requirements.txt --upgrade
