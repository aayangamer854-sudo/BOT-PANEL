from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
app=FastAPI(title='BOT PANEL')
app.mount('/static',StaticFiles(directory='static'),name='static')
templates=Jinja2Templates(directory='templates')
@app.get('/',response_class=HTMLResponse)
def dashboard(request:Request): return templates.TemplateResponse('dashboard.html',{'request':request})
@app.get('/health')
def health(): return {'status':'ok','panel':'BOT PANEL'}
if __name__=='__main__':
 import uvicorn; uvicorn.run(app,host='0.0.0.0',port=int(os.getenv('PORT','8080')))
