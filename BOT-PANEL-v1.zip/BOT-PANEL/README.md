# BOT PANEL v1
Standalone Discord bot hosting panel foundation.

Supports the architecture for Node.js, Python, Bun and optional Docker runtimes.

## Install
```bash
chmod +x *.sh
./install.sh
./start.sh
```
Open `http://YOUR_SERVER_IP:8080`.

This v1 package contains the working FastAPI dashboard and agent/runtime project structure. Production bot execution, authentication, file isolation, WebSocket console and multi-node registration should be added before exposing it publicly.
