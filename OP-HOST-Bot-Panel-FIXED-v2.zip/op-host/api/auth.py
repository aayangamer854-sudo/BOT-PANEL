from __future__ import annotations
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from models.activity import ActivityLog, PasswordReset
from services.auth_service import hash_password, verify_password, create_access_token, generate_reset_token, hash_token, password_meets_policy
from services.common import current_user, audit
from services.notification_manager import notification_manager
from services.security import client_ip, login_allowed, record_login_failure, csrf_token, require_csrf
from config import settings
import re
import secrets

router=APIRouter()
class RegisterIn(BaseModel): username:str=Field(min_length=3,max_length=64); email:EmailStr; password:str=Field(min_length=1,max_length=256)
class LoginIn(BaseModel): login:str=Field(min_length=1,max_length=255); password:str=Field(min_length=1,max_length=256)
class PasswordIn(BaseModel): password:str
class ForgotIn(BaseModel): email:EmailStr
class ResetIn(BaseModel): token:str; password:str=Field(min_length=1,max_length=256)
class ProfileIn(BaseModel): username:str|None=None; email:EmailStr|None=None; avatar:str|None=None

@router.post('/register', status_code=201)
def register(payload:RegisterIn, request:Request, response:Response, db:Session=Depends(get_db)):
    from services.config_store import get_setting
    if str(get_setting(db,'registration',str(settings.ALLOW_REGISTRATION).lower())).lower() not in {'1','true','yes','on'}: raise HTTPException(403,'Registration is disabled')
    if not password_meets_policy(payload.password): raise HTTPException(422,f'Password must be at least {settings.PASSWORD_MIN_LENGTH} characters and contain letters and digits')
    username=payload.username.strip()
    if not re.fullmatch(r'[A-Za-z0-9_.-]{3,64}',username): raise HTTPException(422,'Username may contain letters, numbers, underscore, dot and hyphen')
    if db.query(User).filter(User.username.ilike(username)).first() or db.query(User).filter(User.email.ilike(str(payload.email))).first(): raise HTTPException(409,'Username or email already exists')
    user=User(username=username,email=str(payload.email).lower(),password_hash=hash_password(payload.password),role='User')
    db.add(user); db.commit(); db.refresh(user); audit(db,user,'register',request)
    return {'message':'Registration successful','user':{'id':user.id,'username':user.username,'role':user.role}}

@router.post('/login')
def login(payload:LoginIn, request:Request, response:Response, db:Session=Depends(get_db)):
    ip=client_ip(request)
    if not login_allowed(ip): raise HTTPException(429,'Too many login attempts. Try again later.')
    value=payload.login.strip().lower()
    user=db.query(User).filter((User.email.ilike(value)) | (User.username.ilike(value))).first()
    if not user or not verify_password(payload.password,user.password_hash):
        record_login_failure(ip)
        if user:
            user.failed_login_attempts += 1
            if user.failed_login_attempts>=settings.RATE_LIMIT_LOGIN_ATTEMPTS: user.is_locked=True
            db.commit()
        raise HTTPException(401,'Invalid credentials')
    if not user.is_active or user.is_locked: raise HTTPException(403,'Account is inactive or locked')
    user.failed_login_attempts=0; user.last_login_at=datetime.utcnow(); db.commit()
    token=create_access_token(user.id,user.role)
    csrf=secrets.token_urlsafe(24)
    response.set_cookie('op_access',token,httponly=True,secure=settings.COOKIE_SECURE,samesite='lax',max_age=settings.JWT_EXPIRE_MINUTES*60,path='/')
    response.set_cookie('op_csrf',csrf,httponly=False,secure=settings.COOKIE_SECURE,samesite='lax',max_age=settings.JWT_EXPIRE_MINUTES*60,path='/')
    audit(db,user,'login',request)
    return {'token':token,'user':{'id':user.id,'username':user.username,'email':user.email,'role':user.role}}

@router.post('/logout')
def logout(request:Request,response:Response,user:User=Depends(current_user),db:Session=Depends(get_db)):
    require_csrf(request); audit(db,user,'logout',request)
    response.delete_cookie('op_access',path='/'); response.delete_cookie('op_csrf',path='/')
    return {'message':'Logged out'}

@router.get('/me')
def me(user:User=Depends(current_user)):
    return {'id':user.id,'username':user.username,'email':user.email,'role':user.role,'avatar':user.avatar,'two_factor_enabled':user.two_factor_enabled,'limits':{'max_servers':user.max_servers,'max_ram_mb':user.max_ram_mb,'max_disk_mb':user.max_disk_mb,'max_cpu_percent':user.max_cpu_percent,'max_ports':user.max_ports}}

@router.put('/profile')
def profile(payload:ProfileIn,request:Request,user:User=Depends(current_user),db:Session=Depends(get_db)):
    require_csrf(request)
    if payload.username is not None:
        u=payload.username.strip()
        if not re.fullmatch(r'[A-Za-z0-9_.-]{3,64}',u): raise HTTPException(422,'Invalid username')
        if db.query(User).filter(User.username.ilike(u),User.id!=user.id).first(): raise HTTPException(409,'Username already exists')
        user.username=u
    if payload.email is not None:
        if db.query(User).filter(User.email.ilike(str(payload.email)),User.id!=user.id).first(): raise HTTPException(409,'Email already exists')
        user.email=str(payload.email).lower()
    if payload.avatar is not None: user.avatar=payload.avatar[:512]
    db.commit(); audit(db,user,'profile_update',request); return {'message':'Profile updated'}

@router.post('/change-password')
def change_password(payload:PasswordIn,request:Request,user:User=Depends(current_user),db:Session=Depends(get_db)):
    require_csrf(request)
    if not password_meets_policy(payload.password): raise HTTPException(422,f'Password must be at least {settings.PASSWORD_MIN_LENGTH} characters and contain letters and digits')
    user.password_hash=hash_password(payload.password); db.commit(); audit(db,user,'password_change',request); return {'message':'Password changed'}

@router.post('/forgot-password')
def forgot(payload:ForgotIn,request:Request,db:Session=Depends(get_db)):
    user=db.query(User).filter(User.email.ilike(str(payload.email))).first()
    if user:
        token=generate_reset_token(); db.add(PasswordReset(user_id=user.id,token_hash=hash_token(token),expires_at=datetime.utcnow()+timedelta(minutes=settings.RESET_TOKEN_MINUTES))); db.commit()
        link=f'/reset-password.html?token={token}'
        try: notification_manager.email(user.email,'OP HOST password reset',f'Use this link within {settings.RESET_TOKEN_MINUTES} minutes: {link}')
        except Exception as e: settings.logger.warning('Reset email failed: %s',e)
    return {'message':'If that email exists, reset instructions have been sent.'}

@router.post('/reset-password')
def reset(payload:ResetIn,request:Request,db:Session=Depends(get_db)):
    if not password_meets_policy(payload.password): raise HTTPException(422,f'Password must be at least {settings.PASSWORD_MIN_LENGTH} characters and contain letters and digits')
    row=db.query(PasswordReset).filter_by(token_hash=hash_token(payload.token),used_at=None).first()
    if not row or row.expires_at < datetime.utcnow(): raise HTTPException(400,'Invalid or expired reset token')
    user=db.get(User,row.user_id); user.password_hash=hash_password(payload.password); row.used_at=datetime.utcnow(); user.failed_login_attempts=0; user.is_locked=False; db.commit(); return {'message':'Password reset successful'}
