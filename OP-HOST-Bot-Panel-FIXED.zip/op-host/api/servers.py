from __future__ import annotations
import os, json, uuid, socket, shutil, threading, subprocess, time
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File, BackgroundTasks
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from models.server import Server, ServerResource, EnvironmentVariable, Port, ServerCollaborator, Deployment, ScheduledTask
from services.common import current_user, require_role, accessible_server, can_access_server, audit, json_env, ROLE_ORDER
from services.process_manager import process_manager
from services.docker_manager import docker_manager
from services.file_manager import FileManager
from services.git_manager import git_manager
from services.notification_manager import notification_manager
from config import settings

router=APIRouter()
RUNTIMES={
 'Python': {'versions':['3.9','3.10','3.11','3.12','3.13'],'default':'3.13'},
 'Node.js': {'versions':['18','20','22','latest'],'default':'22'},
 'Bun': {'versions':['latest'],'default':'latest'}, 'Java': {'versions':['21','17','11','latest'],'default':'21'}, 'Custom': {'versions':['latest'],'default':'latest'}
}
class CreateServerIn(BaseModel):
 name:str=Field(min_length=1,max_length=128); description:str=''; runtime:str='Python'; version:str='latest'; startup_command:str|None=None; cpu_limit:int|None=Field(default=None,ge=1,le=6400); ram_limit_mb:int|None=Field(default=None,ge=32,le=1048576); disk_limit_mb:int|None=Field(default=None,ge=64,le=1073741824); process_limit:int=Field(default=64,ge=1,le=4096); auto_restart:bool=True; auto_start:bool=False; max_restarts:int=Field(default=5,ge=0,le=100); restart_delay:int=Field(default=5,ge=1,le=3600); startup_timeout:int=Field(default=60,ge=5,le=3600); runtime_mode:str='native'; working_directory:str|None=None; owner_id:int|None=None; internal_port:int|None=None; public_port:int|None=None; protocol:str='TCP'
class PowerIn(BaseModel): force:bool=False
class EnvIn(BaseModel): name:str=Field(min_length=1,max_length=128); value:str=''; is_secret:bool=False
class DeployGitIn(BaseModel): repository_url:str; branch:str='main'; token:str=''; ssh_key:str=''; install_dependencies:bool=True
class ShareIn(BaseModel): user_id:int; permissions:list[str]
class ScheduleIn(BaseModel): action:str; schedule_type:str; expression:str


def _versioned_executable(candidates, requested):
    for candidate in candidates:
        exe = shutil.which(candidate)
        if not exe:
            continue
        try:
            out = subprocess.check_output([exe, "-c", "import sys; print(f\"{sys.version_info[0]}.{sys.version_info[1]}\")"], text=True, timeout=2).strip()
            if out == requested:
                return exe
        except Exception:
            pass
    return None

def installed_version(runtime,requested):
    requested = str(requested or "latest")
    if runtime=='Python':
        if requested=='latest':
            return shutil.which('python3') or shutil.which('python')
        direct = shutil.which(f'python{requested}')
        if direct:
            return direct
        major_minor = requested.split('.')
        if len(major_minor) == 2:
            return _versioned_executable(['python3','python'], requested)
        return None
    if runtime=='Node.js':
        node=shutil.which('node')
        if not node: return None
        if requested=='latest': return node
        try:
            out=subprocess.check_output([node,'-p','process.versions.node'],text=True,timeout=2).strip()
            return node if out.split('.')[0] == requested else None
        except Exception:
            return None
    if runtime=='Bun':
        return shutil.which('bun') if requested in ('latest','') else shutil.which('bun')
    if runtime=='Java':
        java=shutil.which('java')
        if not java: return None
        if requested=='latest': return java
        try:
            out=subprocess.run([java,'-version'],capture_output=True,text=True,timeout=2).stderr or ''
            import re
            m=re.search(r'version "(\d+)(?:\.(\d+))?',out)
            major=m.group(1) if m else ''
            return java if major == requested else None
        except Exception:
            return None
    return shutil.which('sh')

def default_command(runtime,version):
    if runtime=='Python': return f'python{version if version and version!="latest" else "3"} main.py'
    if runtime=='Node.js': return 'npm start' if os.path.exists('package.json') else 'node index.js'
    if runtime=='Bun': return 'bun index.ts'
    if runtime=='Java': return 'java -jar app.jar'
    return 'sh start.sh'

def allocations(db,user,body):
    if body.owner_id and ROLE_ORDER.get(user.role,0)<ROLE_ORDER['Staff']: raise HTTPException(403,'Only staff may assign another owner')
    owner=db.get(User,body.owner_id or user.id)
    if not owner or not owner.is_active: raise HTTPException(400,'Invalid server owner')
    current=db.query(Server).filter(Server.owner_id==owner.id).count()
    if current>=owner.max_servers and ROLE_ORDER.get(user.role,0)<ROLE_ORDER['Staff']: raise HTTPException(403,'Server quota reached')
    used_ram=sum((s.ram_limit_mb for s in db.query(Server).filter(Server.owner_id==owner.id).all()),0)
    if used_ram+body.ram_limit_mb>owner.max_ram_mb and ROLE_ORDER.get(user.role,0)<ROLE_ORDER['Staff']: raise HTTPException(403,'RAM quota exceeded')
    used_cpu=sum((s.cpu_limit for s in db.query(Server).filter(Server.owner_id==owner.id).all()),0)
    if used_cpu+body.cpu_limit>owner.max_cpu_percent and ROLE_ORDER.get(user.role,0)<ROLE_ORDER['Staff']: raise HTTPException(403,'CPU quota exceeded')
    return owner

def get_port_range(db):
    raw=__import__('services.config_store',fromlist=['get_setting']).get_setting(db,'port_range',f'{settings.PORT_RANGE_START}-{settings.PORT_RANGE_END}')
    try: a,b=map(int,str(raw).split('-',1)); return a,b
    except: return settings.PORT_RANGE_START,settings.PORT_RANGE_END

def allocate_port(db,requested=None):
    start,end=get_port_range(db)
    if requested:
        if db.query(Port).filter_by(public_port=requested).first(): raise HTTPException(409,'Port already allocated')
        if not (start<=requested<=end): raise HTTPException(400,'Port is outside configured pool')
        return requested
    for port in range(start,end+1):
        if db.query(Port).filter_by(public_port=port).first(): continue
        with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
            try: s.bind(('0.0.0.0',port)); return port
            except OSError: continue
    raise HTTPException(409,'No free ports in pool')

def make_workspace(server_id):
    p=(settings.SERVERS_PATH/server_id).resolve(); p.mkdir(parents=True,exist_ok=True); (p/'.op-host').write_text('workspace managed by OP HOST\n'); return str(p)

def deploy_dependencies(server:Server):
    root=Path(server.working_directory)
    try:
        if server.runtime=='Python' and (root/'requirements.txt').exists():
            if server.runtime_mode=='docker' and docker_manager.available():
                image=docker_manager.image_for('Python',server.version); docker_manager._run(['run','--rm','-v',f'{root}:/workspace','-w','/workspace',image,'python','-m','pip','install','-r','requirements.txt'],timeout=900)
            else: subprocess.run(['python3','-m','pip','install','-r','requirements.txt'],cwd=root,check=True,timeout=900,capture_output=True,text=True)
        elif server.runtime=='Node.js' and (root/'package.json').exists():
            if server.runtime_mode=='docker' and docker_manager.available():
                image=docker_manager.image_for('Node.js',server.version); docker_manager._run(['run','--rm','-v',f'{root}:/workspace','-w','/workspace',image,'npm','install'],timeout=900)
            else: subprocess.run(['npm','install'],cwd=root,check=True,timeout=900,capture_output=True,text=True)
    except Exception as e: raise RuntimeError(str(e))

def run_deploy(db_factory,server_id,deployment_id,install=True):
    db=db_factory()
    try:
        d=db.get(Deployment,deployment_id); s=db.get(Server,server_id); d.status='RUNNING'; d.message='Deployment started'; db.commit()
        try:
            if install:
                d.message='Installing dependencies'; db.commit(); deploy_dependencies(s)
            d.status='COMPLETED'; d.message='Deployment completed'; db.commit(); notification_manager.create(db,s.owner_id,'Deployment completed',f'{s.name} deployment completed')
        except Exception as e:
            d.status='FAILED'; d.message=str(e)[:2000]; db.commit(); notification_manager.create(db,s.owner_id,'Deployment failed',f'{s.name}: {str(e)[:500]}','error')
    finally: db.close()

@router.get('/runtime-options')
def runtime_options(user:User=Depends(current_user)):
    result={}
    for runtime,meta in RUNTIMES.items():
        versions=[]
        for v in meta['versions']:
            versions.append({'version':v,'installed':bool(installed_version(runtime,v))})
        result[runtime]={'versions':versions,'default':next((x['version'] for x in versions if x['installed']), meta['default'])}
    result['Docker']={'available':docker_manager.available()}
    return result

@router.get('')
def list_servers(user:User=Depends(current_user),db:Session=Depends(get_db)):
    q=db.query(Server)
    if ROLE_ORDER.get(user.role,0)<ROLE_ORDER['Staff']: q=q.filter(Server.owner_id==user.id)
    rows=q.order_by(Server.created_at.desc()).all()
    return [server_json(db,s) for s in rows]

def server_json(db,s):
    r=db.query(ServerResource).filter_by(server_id=s.id).first(); ports=db.query(Port).filter_by(server_id=s.id).all()
    return {'id':s.id,'name':s.name,'description':s.description,'owner_id':s.owner_id,'runtime':s.runtime,'version':s.version,'startup_command':s.startup_command,'working_directory':s.working_directory,'runtime_mode':s.runtime_mode,'status':s.status,'cpu_limit':s.cpu_limit,'ram_limit_mb':s.ram_limit_mb,'disk_limit_mb':s.disk_limit_mb,'process_limit':s.process_limit,'auto_restart':s.auto_restart,'auto_start':s.auto_start,'restart_count':s.restart_count,'pid':s.pid,'exit_code':s.exit_code,'last_crash_at':s.last_crash_at,'last_start_at':s.last_start_at,'last_stop_at':s.last_stop_at,'resource':{'cpu_percent':r.cpu_percent if r else 0,'ram_mb':r.ram_mb if r else 0,'disk_mb':r.disk_mb if r else 0,'network_rx':r.network_rx if r else 0,'network_tx':r.network_tx if r else 0,'uptime_seconds':r.uptime_seconds if r else 0,'enforcement': 'docker-cgroups' if s.runtime_mode=='docker' else 'native-best-effort'},'ports':[{'id':p.id,'internal_port':p.internal_port,'public_port':p.public_port,'protocol':p.protocol,'is_active':p.is_active} for p in ports], 'native_limits': {'cpu':'best-effort','ram':'best-effort','disk':'quota-not-enforced-native','process':'rlimit-nproc'}}

def user_can_native(s,user): return True

@router.post('',status_code=201)
def create_server(payload:CreateServerIn,request:Request,user:User=Depends(current_user),db:Session=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request)
    from services.config_store import get_setting
    payload.cpu_limit = payload.cpu_limit or int(get_setting(db,'default_cpu_percent',100))
    payload.ram_limit_mb = payload.ram_limit_mb or int(get_setting(db,'default_ram_mb',512))
    payload.disk_limit_mb = payload.disk_limit_mb or int(get_setting(db,'default_disk_mb',2048))
    owner=allocations(db,user,payload)
    if payload.runtime not in RUNTIMES: raise HTTPException(422,'Unsupported runtime')
    if payload.version not in RUNTIMES[payload.runtime]['versions'] and payload.version!='latest': raise HTTPException(422,'Unsupported runtime version')
    mode=payload.runtime_mode.lower();
    if mode not in ('native','docker'): raise HTTPException(422,'runtime_mode must be native or docker')
    if mode=='docker' and not docker_manager.available(): raise HTTPException(409,'Docker runtime requested but Docker is unavailable')
    if mode=='native' and user.role=='User' and not settings.ALLOW_NATIVE_USER_BOTS: raise HTTPException(403,'Native runtime is disabled for normal users; ask an admin or enable ALLOW_NATIVE_USER_BOTS')
    exe=installed_version(payload.runtime,payload.version)
    if mode=='native' and payload.runtime!='Custom' and not exe:
        raise HTTPException(409,f'Requested {payload.runtime} version {payload.version} is not installed on this VPS. Install that runtime or choose an installed version.')
    sid=uuid.uuid4().hex; work=make_workspace(sid)
    command=payload.startup_command or default_command(payload.runtime,payload.version)
    try:
        shlex=__import__('shlex'); parts=shlex.split(command)
        if not parts: raise ValueError
    except: raise HTTPException(422,'Invalid startup command')
    server=Server(id=sid,owner_id=owner.id,name=payload.name.strip(),description=payload.description[:2000],runtime=payload.runtime,version=payload.version,startup_command=command,working_directory=payload.working_directory or work,cpu_limit=payload.cpu_limit,ram_limit_mb=payload.ram_limit_mb,disk_limit_mb=payload.disk_limit_mb,process_limit=payload.process_limit,auto_restart=payload.auto_restart,auto_start=payload.auto_start,max_restarts=payload.max_restarts,restart_delay=payload.restart_delay,startup_timeout=payload.startup_timeout,runtime_mode=mode)
    if server.working_directory!=work:
        p=Path(server.working_directory).resolve()
        try: p.relative_to(settings.SERVERS_PATH.resolve())
        except ValueError: raise HTTPException(400,'Working directory must be inside the servers directory')
        p.mkdir(parents=True,exist_ok=True)
    db.add(server); db.add(ServerResource(server_id=sid)); db.flush()
    public=allocate_port(db,payload.public_port); internal=payload.internal_port or 8000
    db.add(Port(server_id=sid,internal_port=internal,public_port=public,protocol=payload.protocol.upper()))
    db.commit(); audit(db,user,'server_create',request,sid)
    if server.auto_start:
        try:
            if mode=='docker': docker_manager.start(db,server,json_env(db,sid))
            else: process_manager.start(db,server)
        except Exception as e: server.status='ERROR'; db.commit(); raise HTTPException(500,f'Server created but auto-start failed: {e}')
    return server_json(db,server)

@router.get('/{server_id}')
def get_server(server_id:str,user:User=Depends(current_user),db:Session=Depends(get_db)):
    s=accessible_server(db,user,server_id); return server_json(db,s)

def power(server,action,db,user,request,force=False):
    try:
        if server.runtime_mode=='docker':
            if action=='start': docker_manager.start(db,server,json_env(db,server.id))
            elif action=='stop': docker_manager.stop(server,force=force); server.status='STOPPED'; db.commit()
            elif action=='restart': docker_manager.restart(server); server.status='RUNNING'; db.commit()
            elif action=='kill': docker_manager.kill(server); server.status='STOPPED'; db.commit()
        else:
            if action=='start': process_manager.start(db,server)
            elif action=='stop': process_manager.stop(db,server,force=force)
            elif action=='restart': process_manager.restart(db,server)
            elif action=='kill': process_manager.stop(db,server,force=True)
        audit(db,user,f'server_{action}',request,server.id); notification_manager.create(db,server.owner_id,f'Server {action}',f'{server.name} {action} requested')
    except HTTPException: raise
    except Exception as e: raise HTTPException(500,str(e)[:500])
    return {'message':f'{action} completed','status':server.status}

@router.post('/{server_id}/start')
def start(server_id:str,request:Request,user:User=Depends(current_user),db:Session=Depends(get_db)): return power(accessible_server(db,user,server_id,'start'),'start',db,user,request)
@router.post('/{server_id}/stop')
def stop(server_id:str,request:Request,payload:PowerIn=PowerIn(),user:User=Depends(current_user),db:Session=Depends(get_db)): return power(accessible_server(db,user,server_id,'stop'),'stop',db,user,request,payload.force)
@router.post('/{server_id}/restart')
def restart(server_id:str,request:Request,user:User=Depends(current_user),db:Session=Depends(get_db)): return power(accessible_server(db,user,server_id,'restart'),'restart',db,user,request)
@router.post('/{server_id}/kill')
def kill(server_id:str,request:Request,user:User=Depends(current_user),db:Session=Depends(get_db)): return power(accessible_server(db,user,server_id,'stop'),'kill',db,user,request,True)

@router.delete('/{server_id}')
def delete_server(server_id:str,request:Request,user:User=Depends(current_user),db:Session=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings')
    try:
        if s.runtime_mode=='docker': docker_manager.kill(s)
        else: process_manager.stop(db,s,force=True)
    except: pass
    db.query(Port).filter_by(server_id=s.id).delete(); audit(db,user,'server_delete',request,s.id); db.delete(s); db.commit()
    try: shutil.rmtree(Path(s.working_directory).resolve())
    except: pass
    try: shutil.rmtree(settings.BACKUPS_PATH/s.id)
    except: pass
    return {'message':'Server deleted'}

@router.get('/{server_id}/environment')
def get_env(server_id,user=Depends(current_user),db:Session=Depends(get_db)):
    s=accessible_server(db,user,server_id,'settings'); rows=db.query(EnvironmentVariable).filter_by(server_id=s.id).all(); return [{'id':r.id,'name':r.name,'value':r.value if not r.is_secret else '********','is_secret':r.is_secret} for r in rows]
@router.post('/{server_id}/environment')
def add_env(server_id,payload:EnvIn,request:Request,user=Depends(current_user),db:Session=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings');
    if db.query(EnvironmentVariable).filter_by(server_id=s.id,name=payload.name).first(): raise HTTPException(409,'Variable already exists')
    db.add(EnvironmentVariable(server_id=s.id,name=payload.name,value=payload.value,is_secret=payload.is_secret)); db.commit(); audit(db,user,'env_add',request,s.id); return {'message':'Variable added'}
@router.delete('/{server_id}/environment/{env_id}')
def del_env(server_id,env_id,request:Request,user=Depends(current_user),db:Session=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings'); row=db.query(EnvironmentVariable).filter_by(id=env_id,server_id=s.id).first();
    if not row: raise HTTPException(404,'Variable not found')
    db.delete(row); db.commit(); audit(db,user,'env_delete',request,s.id); return {'message':'Variable deleted'}

@router.post('/{server_id}/deploy/github')
def deploy_git(server_id,payload:DeployGitIn,background:BackgroundTasks,request:Request,user=Depends(current_user),db:Session=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings'); d=Deployment(server_id=s.id,kind='git'); db.add(d); db.commit(); db.refresh(d)
    from database import SessionLocal
    def task():
        local=SessionLocal()
        try:
            dep=local.get(Deployment,d.id); srv=local.get(Server,s.id); dep.status='RUNNING'; dep.message='Cloning/pulling Git repository'; local.commit()
            git_manager.deploy(srv,payload.repository_url,payload.branch,payload.token,payload.ssh_key)
            if payload.install_dependencies:
                dep.message='Installing dependencies'; local.commit(); deploy_dependencies(srv)
            dep.status='COMPLETED'; dep.message='Deployment completed'; local.commit(); notification_manager.create(local,srv.owner_id,'Deployment completed',f'{srv.name} deployment completed')
        except Exception as e:
            dep=local.get(Deployment,d.id); dep.status='FAILED'; dep.message=str(e)[:2000]; local.commit(); notification_manager.create(local,srv.owner_id,'Deployment failed',f'{srv.name}: {str(e)[:500]}','error')
        finally: local.close()
    background.add_task(task)
    return {'deployment_id':d.id,'message':'Git deployment started'}

@router.post('/{server_id}/deploy/upload')
def deploy_upload(server_id,file:UploadFile=File(...),background:BackgroundTasks=None,request:Request=None,user=Depends(current_user),db:Session=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); root=Path(s.working_directory); dest=root/Path(file.filename or 'upload.bin').name
    if dest.suffix.lower() not in {'.zip','.tar','.gz','.py','.js','.json','.txt','.yml','.yaml','.md','.env','.sh','.cfg','.ini'} and not dest.name: raise HTTPException(415,'Unsupported file')
    maxb=settings.MAX_UPLOAD_MB*1024*1024; written=0
    with open(dest,'wb') as f:
        while chunk:=file.file.read(1024*1024):
            written+=len(chunk)
            if written>maxb: f.close(); dest.unlink(missing_ok=True); raise HTTPException(413,'Upload too large')
            f.write(chunk)
    d=Deployment(server_id=s.id,kind='upload',status='COMPLETED',message=f'Uploaded {dest.name}'); db.add(d); db.commit(); audit(db,user,'file_upload',request,s.id); return {'message':'Upload completed','path':dest.name}

@router.get('/{server_id}/deployment/{deployment_id}')
def deployment(server_id,deployment_id,user=Depends(current_user),db=Depends(get_db)):
    s=accessible_server(db,user,server_id); d=db.query(Deployment).filter_by(id=deployment_id,server_id=s.id).first();
    if not d: raise HTTPException(404,'Deployment not found')
    return {'id':d.id,'status':d.status,'kind':d.kind,'message':d.message,'created_at':d.created_at,'updated_at':d.updated_at}

@router.post('/{server_id}/collaborators')
def share(server_id,payload:ShareIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings'); target=db.get(User,payload.user_id)
    if not target: raise HTTPException(404,'User not found')
    c=db.query(ServerCollaborator).filter_by(server_id=s.id,user_id=target.id).first() or ServerCollaborator(server_id=s.id,user_id=target.id)
    allowed={'console','files','start','stop','restart','settings','view_resources'}; perms=[p for p in payload.permissions if p in allowed]; c.permissions=','.join(perms); db.add(c); db.commit(); return {'message':'Collaborator saved','permissions':perms}
@router.delete('/{server_id}/collaborators/{user_id}')
def unshare(server_id,user_id,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings'); c=db.query(ServerCollaborator).filter_by(server_id=s.id,user_id=user_id).first();
    if c: db.delete(c); db.commit()
    return {'message':'Collaborator removed'}

@router.post('/{server_id}/schedules')
def add_schedule(server_id,payload:ScheduleIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); from services.scheduler import scheduler_service
    s=accessible_server(db,user,server_id,'settings');
    if payload.action not in {'start','stop','restart','backup'} or payload.schedule_type not in {'interval','hourly','daily','weekly','cron'}: raise HTTPException(422,'Invalid schedule')
    task=ScheduledTask(server_id=s.id,action=payload.action,schedule_type=payload.schedule_type,expression=payload.expression,enabled=True)
    try: task.next_run_at=scheduler_service.calc_next(task,__import__('datetime').datetime.utcnow())
    except Exception as e: raise HTTPException(422,f'Invalid schedule expression: {e}')
    db.add(task); db.commit(); return {'id':task.id,'next_run_at':task.next_run_at}

@router.delete('/{server_id}/schedules/{task_id}')
def delete_schedule(server_id,task_id,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings'); t=db.query(ScheduledTask).filter_by(id=task_id,server_id=s.id).first();
    if t: db.delete(t); db.commit()
    return {'message':'Schedule deleted'}


class ServerPatch(BaseModel):
    name:str|None=None; description:str|None=None; startup_command:str|None=None; cpu_limit:int|None=None; ram_limit_mb:int|None=None; disk_limit_mb:int|None=None; process_limit:int|None=None; auto_restart:bool|None=None; auto_start:bool|None=None; max_restarts:int|None=None; restart_delay:int|None=None; startup_timeout:int|None=None
@router.patch('/{server_id}')
def patch_server(server_id,payload:ServerPatch,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings')
    if payload.startup_command is not None:
        try:
            if not __import__('shlex').split(payload.startup_command): raise ValueError
        except: raise HTTPException(422,'Invalid startup command')
    for name in ('name','description','startup_command','cpu_limit','ram_limit_mb','disk_limit_mb','process_limit','auto_restart','auto_start','max_restarts','restart_delay','startup_timeout'):
        val=getattr(payload,name)
        if val is not None: setattr(s,name,val)
    db.commit(); audit(db,user,'server_settings',request,s.id); return server_json(db,s)

class PortIn(BaseModel): internal_port:int=Field(ge=1,le=65535); public_port:int|None=None; protocol:str='TCP'
@router.post('/{server_id}/ports')
def add_port(server_id,payload:PortIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings');
    owner=db.get(User,s.owner_id)
    if db.query(Port).filter_by(server_id=s.id).count()>=owner.max_ports and user.role=='User': raise HTTPException(403,'Port quota reached')
    public=allocate_port(db,payload.public_port); p=Port(server_id=s.id,internal_port=payload.internal_port,public_port=public,protocol=payload.protocol.upper()); db.add(p); db.commit(); return {'id':p.id,'public_port':p.public_port}
@router.delete('/{server_id}/ports/{port_id}')
def delete_port(server_id,port_id,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings'); p=db.query(Port).filter_by(id=port_id,server_id=s.id).first();
    if not p: raise HTTPException(404,'Port not found')
    db.delete(p); db.commit(); return {'message':'Port released'}

class EnvUpdate(BaseModel): value:str; is_secret:bool|None=None
@router.put('/{server_id}/environment/{env_id}')
def edit_env(server_id,env_id,payload:EnvUpdate,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings'); e=db.query(EnvironmentVariable).filter_by(id=env_id,server_id=s.id).first();
    if not e: raise HTTPException(404,'Variable not found')
    e.value=payload.value; e.is_secret=e.is_secret if payload.is_secret is None else payload.is_secret; db.commit(); return {'message':'Variable updated'}

@router.get('/{server_id}/collaborators')
def collaborators(server_id,user=Depends(current_user),db=Depends(get_db)):
    s=accessible_server(db,user,server_id,'settings'); rows=db.query(ServerCollaborator,User).join(User,User.id==ServerCollaborator.user_id).filter(ServerCollaborator.server_id==s.id).all(); return [{'user_id':u.id,'username':u.username,'permissions':c.permissions.split(',') if c.permissions else []} for c,u in rows]
@router.get('/{server_id}/schedules')
def schedules(server_id,user=Depends(current_user),db=Depends(get_db)):
    s=accessible_server(db,user,server_id,'settings'); rows=db.query(ScheduledTask).filter_by(server_id=s.id).order_by(ScheduledTask.id.desc()).all(); return [{'id':t.id,'action':t.action,'schedule_type':t.schedule_type,'expression':t.expression,'enabled':t.enabled,'next_run_at':t.next_run_at,'last_run_at':t.last_run_at} for t in rows]


from fastapi.responses import PlainTextResponse
@router.get('/{server_id}/environment/export')
def export_env(server_id,user=Depends(current_user),db=Depends(get_db)):
    s=accessible_server(db,user,server_id,'settings'); rows=db.query(EnvironmentVariable).filter_by(server_id=s.id).all()
    lines=[]
    for r in rows:
        value=r.value.replace('\\','\\\\').replace('\n','\\n').replace('"','\\"')
        lines.append(f'{r.name}="{value}"')
    return PlainTextResponse('\n'.join(lines)+'\n',media_type='text/plain',headers={'Content-Disposition':f'attachment; filename="{s.id}.env"'})
class EnvImport(BaseModel): content:str=Field(max_length=1000000); replace:bool=False
@router.post('/{server_id}/environment/import')
def import_env(server_id,payload:EnvImport,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'settings');
    if payload.replace: db.query(EnvironmentVariable).filter_by(server_id=s.id).delete()
    count=0
    for raw in payload.content.splitlines():
        line=raw.strip()
        if not line or line.startswith('#'): continue
        if '=' not in line: continue
        name,val=line.split('=',1); name=name.strip(); val=val.strip()
        if not name or len(name)>128: continue
        if len(val)>=2 and val[0] in {'"',"'"} and val[-1]==val[0]: val=val[1:-1]
        e=db.query(EnvironmentVariable).filter_by(server_id=s.id,name=name).first() or EnvironmentVariable(server_id=s.id,name=name)
        e.value=val; db.add(e); count+=1
    db.commit(); audit(db,user,'env_import',request,s.id); return {'message':'Environment imported','count':count}
