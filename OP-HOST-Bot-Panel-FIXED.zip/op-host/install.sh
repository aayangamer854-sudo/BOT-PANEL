#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${OP_HOST_DIR:-/opt/op-host}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
SERVICE_NAME="op-host.service"

say(){ printf '\n[OP HOST] %s\n' "$*"; }
need_root(){ if [ "$(id -u)" -ne 0 ]; then say "Run installer as root: sudo ./install.sh"; exit 1; fi; }
need_root

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then echo "Python 3 is required."; exit 1; fi
PY_VER="$($PYTHON_BIN -c 'import sys; print(sys.version_info[0],sys.version_info[1])')"
MAJOR="${PY_VER% *}"; MINOR="${PY_VER#* }"
if [ "$MAJOR" -lt 3 ] || [ "$MAJOR" -eq 3 ] && [ "$MINOR" -lt 11 ]; then echo "Python 3.11+ is required."; exit 1; fi

say "Installing application into $APP_DIR"
mkdir -p "$APP_DIR"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ "$SCRIPT_DIR" != "$APP_DIR" ]; then
  cp -a "$SCRIPT_DIR"/. "$APP_DIR"/
fi
mkdir -p "$APP_DIR"/{data,logs,servers,backups,config}

if ! id -u op-host >/dev/null 2>&1; then
  useradd --system --home-dir "$APP_DIR" --shell /usr/sbin/nologin op-host
fi
chown -R op-host:op-host "$APP_DIR"
if getent group docker >/dev/null 2>&1; then usermod -aG docker op-host || true; fi

say "Creating Python virtual environment"
if [ ! -d "$APP_DIR/.venv" ]; then "$PYTHON_BIN" -m venv "$APP_DIR/.venv"; fi
"$APP_DIR/.venv/bin/python" -m pip install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"

if [ ! -f "$APP_DIR/.env" ]; then
  PANEL_NAME="OP HOST Bot Panel"
  read -r -p "Panel name [$PANEL_NAME]: " INPUT_NAME || true
  PANEL_NAME="${INPUT_NAME:-$PANEL_NAME}"
  read -r -p "Admin username [admin]: " ADMIN_USER || true; ADMIN_USER="${ADMIN_USER:-admin}"
  read -r -p "Admin email [admin@example.com]: " ADMIN_EMAIL || true; ADMIN_EMAIL="${ADMIN_EMAIL:-admin@example.com}"
  while true; do read -r -s -p "Admin password (letters + digits, 8+): " ADMIN_PASS; echo; if "$APP_DIR/.venv/bin/python" - <<PY
p=${ADMIN_PASS@Q}
import re; print(bool(len(p)>=8 and re.search(r'[A-Za-z]',p) and re.search(r'\d',p)))
PY
then break; else echo "Password does not meet policy."; fi; done
  SECRET="$($APP_DIR/.venv/bin/python - <<'PY'
import secrets; print(secrets.token_urlsafe(48))
PY
)"
  JWT_SECRET="$($APP_DIR/.venv/bin/python - <<'PY'
import secrets; print(secrets.token_urlsafe(48))
PY
)"
  SESSION_SECRET="$($APP_DIR/.venv/bin/python - <<'PY'
import secrets; print(secrets.token_urlsafe(48))
PY
)"
  cat > "$APP_DIR/.env" <<EOF
PANEL_NAME=$(printf '%s' "$PANEL_NAME" | sed 's/[&|]/_/g')
HOST=0.0.0.0
PORT=7070
SECRET_KEY=$SECRET
JWT_SECRET=$JWT_SECRET
SESSION_SECRET=$SESSION_SECRET
DATABASE_URL=sqlite:///$APP_DIR/data/panel.db
COOKIE_SECURE=false
ALLOW_REGISTRATION=true
ALLOW_NATIVE_USER_BOTS=true
PORT_RANGE_START=8001
PORT_RANGE_END=8999
BOOTSTRAP_ADMIN_USERNAME=$ADMIN_USER
BOOTSTRAP_ADMIN_EMAIL=$ADMIN_EMAIL
BOOTSTRAP_ADMIN_PASSWORD=$ADMIN_PASS
MAX_UPLOAD_MB=100
EOF
  chmod 600 "$APP_DIR/.env"
fi
chown op-host:op-host "$APP_DIR/.env"

if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null || true)" = "systemd" ]; then
  say "Creating systemd service"
  cat > /etc/systemd/system/$SERVICE_NAME <<EOF
[Unit]
Description=OP HOST Bot Panel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=op-host
Group=op-host
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/.venv/bin/python $APP_DIR/app.py
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
ReadWritePaths=$APP_DIR

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable "$SERVICE_NAME"
  systemctl restart "$SERVICE_NAME"
else
  say "systemd not available; using PID-file launcher"
  "$APP_DIR/start.sh"
fi
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
IP="${IP:-SERVER_IP}"
say "OP HOST installed successfully!"
echo "Panel: http://$IP:7070"
echo "App: $APP_DIR"
echo "Start: $APP_DIR/start.sh"
echo "Docs: http://$IP:7070/docs"
