import os
HOST=os.getenv('HOST','0.0.0.0'); PORT=int(os.getenv('PORT','7878'))
DATA_DIR=os.getenv('DATA_DIR','data'); STORAGE_DIR=os.getenv('STORAGE_DIR','storage')
os.makedirs(DATA_DIR,exist_ok=True); os.makedirs(STORAGE_DIR,exist_ok=True)
