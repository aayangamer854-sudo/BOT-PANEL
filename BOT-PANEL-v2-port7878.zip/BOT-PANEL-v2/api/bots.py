from fastapi import APIRouter,HTTPException
from pydantic import BaseModel
from database import connect
router=APIRouter(); VALID={'nodejs','python','bun','docker'}
class BotCreate(BaseModel):
 name:str; runtime:str='nodejs'; entry:str='index.js'
@router.get('/bots')
def list_bots():
 c=connect(); x=[dict(r) for r in c.execute('SELECT * FROM bots ORDER BY id DESC')]; c.close(); return x
@router.post('/bots')
def create_bot(d:BotCreate):
 if d.runtime not in VALID: raise HTTPException(400,'Unsupported runtime')
 c=connect(); cur=c.execute('INSERT INTO bots(name,runtime,entry) VALUES(?,?,?)',(d.name,d.runtime,d.entry)); c.commit(); i=cur.lastrowid; c.close(); return {'id':i,'name':d.name,'runtime':d.runtime,'entry':d.entry,'status':'stopped'}
def set_status(i,s):
 c=connect(); cur=c.execute('UPDATE bots SET status=? WHERE id=?',(s,i)); c.commit(); c.close()
 if not cur.rowcount: raise HTTPException(404,'Bot not found')
 return {'id':i,'status':s}
@router.post('/bots/{i}/start')
def start(i:int): return set_status(i,'running')
@router.post('/bots/{i}/stop')
def stop(i:int): return set_status(i,'stopped')
@router.post('/bots/{i}/restart')
def restart(i:int): return set_status(i,'running')
@router.delete('/bots/{i}')
def delete(i:int):
 c=connect(); cur=c.execute('DELETE FROM bots WHERE id=?',(i,)); c.commit(); c.close()
 if not cur.rowcount: raise HTTPException(404,'Bot not found')
 return {'deleted':True}
