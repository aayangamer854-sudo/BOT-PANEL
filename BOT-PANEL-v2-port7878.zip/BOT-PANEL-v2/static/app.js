async function api(u,o={}){let r=await fetch(u,{headers:{'Content-Type':'application/json'},...o});return r.json()}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function load(){let bs=await api('/api/bots');document.querySelector('#bots').innerHTML=bs.length?bs.map(b=>`<div class="card"><h3>${esc(b.name)}</h3><div class="muted">${esc(b.runtime)} • ${esc(b.entry)}</div><div class="status">Status: <b>${esc(b.status)}</b></div><div class="actions"><button onclick="act(${b.id},'start')">Start</button><button onclick="act(${b.id},'stop')">Stop</button><button onclick="act(${b.id},'restart')">Restart</button><button class="danger" onclick="delBot(${b.id})">Delete</button></div></div>`).join(''):`<div class="card"><h3>No bots yet</h3><div class="muted">Create your first bot.</div></div>`}
async function createBot(){let name=prompt('Bot name?');if(!name)return;let runtime=prompt('Runtime: nodejs / python / bun','nodejs')||'nodejs';let entry=runtime==='python'?'main.py':runtime==='bun'?'index.ts':'index.js';await api('/api/bots',{method:'POST',body:JSON.stringify({name,runtime,entry})});load()}
async function act(id,a){await api(`/api/bots/${id}/${a}`,{method:'POST'});load()}
async function delBot(id){if(confirm('Delete this bot?')){await api(`/api/bots/${id}`,{method:'DELETE'});load()}}
load()
