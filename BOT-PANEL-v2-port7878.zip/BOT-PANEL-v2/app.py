from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request
from api.bots import router as bots_router
app=FastAPI(title='BOT PANEL',version='2.0')
app.mount('/static',StaticFiles(directory='static'),name='static')
templates=Jinja2Templates(directory='templates')
app.include_router(bots_router,prefix='/api')
@app.get('/',response_class=HTMLResponse)
async def dashboard(request:Request): return templates.TemplateResponse('dashboard.html',{'request':request})
@app.get('/health')
def health(): return {'status':'ok'}
