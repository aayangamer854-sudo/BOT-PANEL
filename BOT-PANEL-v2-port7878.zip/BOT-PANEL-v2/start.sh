#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
. .venv/bin/activate
exec python -m uvicorn app:app --host "${HOST:-0.0.0.0}" --port "${PORT:-7878}"
