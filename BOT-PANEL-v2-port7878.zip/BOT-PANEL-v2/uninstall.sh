#!/usr/bin/env bash
set -e
rm -rf .venv
echo 'Virtual environment removed; project data kept.'
