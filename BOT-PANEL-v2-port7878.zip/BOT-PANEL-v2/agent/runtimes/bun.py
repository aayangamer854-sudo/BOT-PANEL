# bun runtime adapter placeholder
