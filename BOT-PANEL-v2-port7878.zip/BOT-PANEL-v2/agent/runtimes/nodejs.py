# nodejs runtime adapter placeholder
