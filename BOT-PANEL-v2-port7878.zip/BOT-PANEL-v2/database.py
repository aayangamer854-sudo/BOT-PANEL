import sqlite3,os
from config import DATA_DIR
DB=os.path.join(DATA_DIR,'botpanel.db')
def connect():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init_db():
 c=connect(); c.execute('CREATE TABLE IF NOT EXISTS bots(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,runtime TEXT NOT NULL,entry TEXT NOT NULL,status TEXT DEFAULT "stopped")'); c.commit(); c.close()
init_db()
