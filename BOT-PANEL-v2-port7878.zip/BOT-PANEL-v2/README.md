# BOT-PANEL-v2
Default port: **7878**

Install:
```bash
chmod +x install.sh start.sh update.sh uninstall.sh
./install.sh
./start.sh
```
Open `http://YOUR_VPS_IP:7878`.

Firewall: `sudo ufw allow 7878/tcp`

Custom port: `PORT=3000 ./start.sh`
