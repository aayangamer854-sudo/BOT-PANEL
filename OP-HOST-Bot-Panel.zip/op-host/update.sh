#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"; TMP="$APP_DIR/data/update-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$TMP"
cp -a "$APP_DIR/data/panel.db" "$TMP/panel.db" 2>/dev/null || true
cp -a "$APP_DIR/.env" "$TMP/.env" 2>/dev/null || true
if [ -d "$APP_DIR/.git" ] && command -v git >/dev/null 2>&1; then git -C "$APP_DIR" fetch --all --prune; git -C "$APP_DIR" pull --ff-only; else echo "No Git checkout detected; update script will only refresh Python dependencies."; fi
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
"$APP_DIR/.venv/bin/python" "$APP_DIR/migrate.py"
"$APP_DIR/restart.sh"
echo "Update complete. Backup: $TMP"
