"""OP HOST Bot Panel application entry point."""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from config import settings
from database import init_db, SessionLocal
from services.scheduler import scheduler_service
from services.resource_manager import resource_service
from api.auth import router as auth_router
from api.servers import router as servers_router
from api.users import router as users_router
from api.files import router as files_router
from api.console import router as console_router
from api.resources import router as resources_router
from api.backups import router as backups_router
from api.api_keys import router as api_keys_router
from api.admin import router as admin_router
from api.ui import router as ui_router
from api.ws import router as ws_router
from api.notifications import router as notifications_router
from api.billing import router as billing_router
from services.security import SecurityHeadersMiddleware

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    scheduler_service.start()
    resource_service.start()
    yield
    resource_service.stop()
    scheduler_service.stop()

app = FastAPI(title=settings.PANEL_NAME, version=settings.VERSION, docs_url="/docs", redoc_url="/redoc", lifespan=lifespan)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(SessionMiddleware, secret_key=settings.SESSION_SECRET, https_only=settings.COOKIE_SECURE, same_site="lax", max_age=settings.SESSION_MAX_AGE)
app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS or ["http://127.0.0.1:7070", "http://localhost:7070"], allow_credentials=True, allow_methods=["GET","POST","PUT","PATCH","DELETE","OPTIONS"], allow_headers=["Authorization","Content-Type","X-CSRF-Token"])
app.mount("/static", StaticFiles(directory=str(settings.BASE_DIR / "static")), name="static")

@app.exception_handler(Exception)
async def unhandled_exception(request: Request, exc: Exception):
    settings.logger.exception("Unhandled exception for %s %s", request.method, request.url.path)
    if request.url.path.startswith("/api/"):
        return JSONResponse(status_code=500, content={"detail":"Internal server error"})
    return JSONResponse(status_code=500, content={"detail":"Internal server error"})

app.include_router(ui_router)
app.include_router(auth_router, prefix="/api/auth", tags=["auth"])
app.include_router(servers_router, prefix="/api/servers", tags=["servers"])
app.include_router(files_router, prefix="/api/servers", tags=["files"])
app.include_router(console_router, prefix="/api/servers", tags=["console"])
app.include_router(resources_router, prefix="/api/servers", tags=["resources"])
app.include_router(backups_router, prefix="/api/servers", tags=["backups"])
app.include_router(users_router, prefix="/api/users", tags=["users"])
app.include_router(api_keys_router, prefix="/api/keys", tags=["api-keys"])
app.include_router(admin_router, prefix="/api/admin", tags=["admin"])
app.include_router(ws_router)
app.include_router(notifications_router, prefix="/api/notifications", tags=["notifications"])
app.include_router(billing_router, prefix="/api/billing", tags=["billing"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host=settings.HOST, port=settings.PORT, log_level=settings.LOG_LEVEL.lower())
