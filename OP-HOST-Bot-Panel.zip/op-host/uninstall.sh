#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
read -r -p "Stop and uninstall OP HOST from $APP_DIR? [y/N]: " ans || true
[[ "$ans" =~ ^[Yy]$ ]] || exit 0
"$APP_DIR/stop.sh" || true
if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null || true)" = "systemd" ]; then systemctl disable --now op-host.service 2>/dev/null || true; rm -f /etc/systemd/system/op-host.service; systemctl daemon-reload || true; fi
read -r -p "Create a backup of data, servers and backups before removal? [Y/n]: " b || true
if [[ ! "$b" =~ ^[Nn]$ ]]; then tar -czf "${APP_DIR}-backup-$(date +%Y%m%d-%H%M%S).tar.gz" "$APP_DIR/data" "$APP_DIR/servers" "$APP_DIR/backups" "$APP_DIR/.env" 2>/dev/null || true; fi
read -r -p "Delete server data and backups? [y/N]: " d || true
if [[ "$d" =~ ^[Yy]$ ]]; then rm -rf "$APP_DIR/servers" "$APP_DIR/backups" "$APP_DIR/data"; else echo "Server data, backups and database retained."; fi
read -r -p "Remove application code and virtualenv? [y/N]: " c || true
if [[ "$c" =~ ^[Yy]$ ]]; then rm -rf "$APP_DIR"; fi
echo "Uninstall finished."
