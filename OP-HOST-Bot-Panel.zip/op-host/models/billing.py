from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from database import Base
class Plan(Base):
    __tablename__='plans'
    id=Column(Integer,primary_key=True)
    name=Column(String(64),unique=True,nullable=False)
    ram_mb=Column(Integer,default=1024)
    cpu_percent=Column(Integer,default=100)
    disk_mb=Column(Integer,default=5120)
    max_servers=Column(Integer,default=1)
    max_ports=Column(Integer,default=2)
    enabled=Column(Boolean,default=True)
class Subscription(Base):
    __tablename__='subscriptions'
    id=Column(Integer,primary_key=True)
    user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),unique=True)
    plan_id=Column(Integer,ForeignKey('plans.id'))
    status=Column(String(32),default='active')
    created_at=Column(DateTime,default=datetime.utcnow)
    expires_at=Column(DateTime)
