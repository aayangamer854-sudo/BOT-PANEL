from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey
from database import Base
class ActivityLog(Base):
    __tablename__ = "activity_logs"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="SET NULL"))
    action = Column(String(128), nullable=False)
    details = Column(Text, default="")
    ip_address = Column(String(64))
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
class PasswordReset(Base):
    __tablename__ = "password_resets"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    token_hash = Column(String(255), unique=True, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
