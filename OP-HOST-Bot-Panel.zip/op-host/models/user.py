from __future__ import annotations
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text
from database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(512), nullable=False)
    role = Column(String(20), nullable=False, default="User")
    is_active = Column(Boolean, nullable=False, default=True)
    is_locked = Column(Boolean, nullable=False, default=False)
    failed_login_attempts = Column(Integer, nullable=False, default=0)
    last_login_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    avatar = Column(String(512))
    two_factor_secret = Column(String(255))
    two_factor_enabled = Column(Boolean, nullable=False, default=False)
    max_servers = Column(Integer, default=3)
    max_ram_mb = Column(Integer, default=2048)
    max_disk_mb = Column(Integer, default=10240)
    max_cpu_percent = Column(Integer, default=200)
    max_ports = Column(Integer, default=5)
