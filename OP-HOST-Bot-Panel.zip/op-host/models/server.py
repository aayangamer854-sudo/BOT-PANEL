from __future__ import annotations
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, Float, UniqueConstraint
from database import Base

class Server(Base):
    __tablename__ = "servers"
    id = Column(String(64), primary_key=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    name = Column(String(128), nullable=False)
    description = Column(Text, default="")
    runtime = Column(String(20), nullable=False, default="Python")
    version = Column(String(32), default="latest")
    startup_command = Column(Text, nullable=False)
    working_directory = Column(String(1024), nullable=False)
    cpu_limit = Column(Integer, nullable=False, default=100)
    ram_limit_mb = Column(Integer, nullable=False, default=512)
    disk_limit_mb = Column(Integer, nullable=False, default=2048)
    process_limit = Column(Integer, default=64)
    auto_restart = Column(Boolean, default=True)
    auto_start = Column(Boolean, default=False)
    max_restarts = Column(Integer, default=5)
    restart_delay = Column(Integer, default=5)
    startup_timeout = Column(Integer, default=60)
    runtime_mode = Column(String(20), default="native")
    status = Column(String(20), default="STOPPED")
    pid = Column(Integer)
    container_id = Column(String(128))
    exit_code = Column(Integer)
    restart_count = Column(Integer, default=0)
    last_crash_at = Column(DateTime)
    last_start_at = Column(DateTime)
    last_stop_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ServerRuntime(Base):
    __tablename__ = "server_runtimes"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), unique=True)
    runtime = Column(String(20))
    version = Column(String(32))
    docker_image = Column(String(255))

class ServerResource(Base):
    __tablename__ = "server_resources"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), unique=True)
    cpu_percent = Column(Float, default=0)
    ram_mb = Column(Float, default=0)
    disk_mb = Column(Float, default=0)
    network_rx = Column(Integer, default=0)
    network_tx = Column(Integer, default=0)
    uptime_seconds = Column(Integer, default=0)
    sampled_at = Column(DateTime, default=datetime.utcnow)

class ServerFile(Base):
    __tablename__ = "server_files"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    path = Column(String(2048), nullable=False)
    size = Column(Integer, default=0)
    modified_at = Column(DateTime, default=datetime.utcnow)
    __table_args__ = (UniqueConstraint('server_id','path',name='uq_server_file_path'),)

class ServerLog(Base):
    __tablename__ = "server_logs"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    line = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

class EnvironmentVariable(Base):
    __tablename__ = "environment_variables"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    name = Column(String(128), nullable=False)
    value = Column(Text, default="")
    is_secret = Column(Boolean, default=False)
    __table_args__ = (UniqueConstraint('server_id','name',name='uq_server_env_name'),)

class Port(Base):
    __tablename__ = "ports"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    internal_port = Column(Integer, nullable=False)
    public_port = Column(Integer, nullable=False, unique=True)
    protocol = Column(String(5), default="TCP")
    is_active = Column(Boolean, default=True)

class ServerCollaborator(Base):
    __tablename__ = "server_collaborators"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    permissions = Column(Text, default="console,files,start,stop,restart,view_resources")
    __table_args__ = (UniqueConstraint('server_id','user_id',name='uq_server_collab'),)

class Settings(Base):
    __tablename__ = "settings"
    id = Column(Integer, primary_key=True)
    key = Column(String(128), unique=True, nullable=False)
    value = Column(Text, default="")

class Deployment(Base):
    __tablename__ = "deployments"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    status = Column(String(20), default="QUEUED")
    kind = Column(String(20), default="upload")
    message = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ScheduledTask(Base):
    __tablename__ = "scheduled_tasks"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    action = Column(String(20), nullable=False)
    schedule_type = Column(String(20), nullable=False)
    expression = Column(String(255), nullable=False)
    enabled = Column(Boolean, default=True)
    next_run_at = Column(DateTime)
    last_run_at = Column(DateTime)

class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    level = Column(String(20), default="info")
    read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
