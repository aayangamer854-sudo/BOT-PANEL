from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from database import Base
class Backup(Base):
    __tablename__ = "backups"
    id = Column(Integer, primary_key=True)
    server_id = Column(String(64), ForeignKey("servers.id", ondelete="CASCADE"), index=True)
    filename = Column(String(255), nullable=False)
    path = Column(String(2048), nullable=False)
    size = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
