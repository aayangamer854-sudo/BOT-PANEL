"""Database setup."""
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from config import settings

connect_args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(settings.DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)
Base = declarative_base()

def init_db():
    from models.user import User
    from models.server import Server, ServerRuntime, ServerResource, ServerFile, ServerLog, EnvironmentVariable, Port, ServerCollaborator, Settings as SettingsModel, Deployment, ScheduledTask, Notification
    from models.api_key import ApiKey
    from models.backup import Backup
    from models.activity import ActivityLog, PasswordReset
    from models.billing import Plan, Subscription
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        from models.user import User
        if not db.query(User).filter(User.role == "Owner").first():
            admin_user = (settings.__dict__.get("BOOTSTRAP_ADMIN_USERNAME") or __import__("os").environ.get("BOOTSTRAP_ADMIN_USERNAME"))
            admin_email = __import__("os").environ.get("BOOTSTRAP_ADMIN_EMAIL")
            admin_password = __import__("os").environ.get("BOOTSTRAP_ADMIN_PASSWORD")
            if admin_user and admin_email and admin_password:
                from services.auth_service import hash_password
                user = User(username=admin_user, email=admin_email.lower(), password_hash=hash_password(admin_password), role="Owner", is_active=True)
                db.add(user); db.commit()
        from models.billing import Plan
        if db.query(Plan).count()==0:
            db.add_all([Plan(name="Free",ram_mb=1024,cpu_percent=100,disk_mb=5120,max_servers=1,max_ports=2),Plan(name="Basic",ram_mb=4096,cpu_percent=200,disk_mb=20480,max_servers=3,max_ports=5),Plan(name="Pro",ram_mb=16384,cpu_percent=400,disk_mb=102400,max_servers=10,max_ports=20),Plan(name="Custom",ram_mb=32768,cpu_percent=800,disk_mb=204800,max_servers=25,max_ports=50)]); db.commit()
    finally:
        db.close()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
