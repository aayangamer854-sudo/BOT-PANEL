#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"; PID_FILE="$APP_DIR/data/panel.pid"
if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null || true)" = "systemd" ] && systemctl list-unit-files op-host.service >/dev/null 2>&1; then systemctl stop op-host.service; echo "OP HOST service stopped"; exit 0; fi
if [ ! -f "$PID_FILE" ]; then echo "Panel is not running"; exit 0; fi
pid=$(cat "$PID_FILE")
if kill -0 "$pid" 2>/dev/null; then kill "$pid"; for _ in $(seq 1 20); do kill -0 "$pid" 2>/dev/null || break; sleep .25; done; if kill -0 "$pid" 2>/dev/null; then kill -9 "$pid" || true; fi; fi
rm -f "$PID_FILE"; echo "Stopped OP HOST"
