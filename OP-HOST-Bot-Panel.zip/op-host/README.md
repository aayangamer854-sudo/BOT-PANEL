# OP HOST Bot Panel

Production-oriented FastAPI bot hosting panel for Linux VPSs. The panel itself does not require Docker. Hosted bots can run with the native Linux process runtime or, preferably for untrusted code, the optional Docker runtime.

## Requirements

- Linux VPS recommended
- Python 3.11+
- Git for Git deployments
- Docker optional for isolated bot containers
- systemd optional; PID-file mode works without it
- PostgreSQL optional; SQLite is the default

## Install

```bash
sudo ./install.sh
```

The installer creates `/opt/op-host`, a Python virtualenv, the database directories, an `op-host` service account, an interactive Owner account, and a systemd service when systemd is available.

Panel default:

```text
HOST=0.0.0.0
PORT=7070
http://SERVER_IP:7070
```

Swagger/OpenAPI:

```text
http://SERVER_IP:7070/docs
```

The installer generates random JWT/session secrets and writes them to `.env` with mode `600`.

## Manual control

```bash
./start.sh
./stop.sh
./restart.sh
```

When systemd is unavailable, the scripts use `data/panel.pid` and launch:

```bash
nohup .venv/bin/python app.py > logs/panel.log 2>&1 &
```

Direct startup also works:

```bash
python3 app.py
```

or:

```bash
.venv/bin/uvicorn app:app --host 0.0.0.0 --port 7070
```

## First login

Use the Owner credentials entered during `install.sh`. The same account is created automatically from `BOOTSTRAP_ADMIN_USERNAME`, `BOOTSTRAP_ADMIN_EMAIL`, and `BOOTSTRAP_ADMIN_PASSWORD` when no Owner exists.

## Create a bot server

Open **Servers → Create Server** and choose:

- Python, Node.js, Bun, Java, or Custom
- an installed runtime version
- Native or Docker mode
- CPU, RAM, disk metadata, process limit
- startup command
- internal/public TCP or UDP port
- automatic restart/start options

The runtime options endpoint probes installed executables so unavailable Python/Node versions are not offered by the panel API.

## Python bot setup

Example files:

```text
main.py
requirements.txt
```

Recommended command:

```text
python3 main.py
```

When `requirements.txt` exists, deployment can run `pip install -r requirements.txt`.

## Node.js bot setup

Example:

```text
index.js
package.json
```

Startup options include:

```text
node index.js
npm start
```

A `package.json` triggers `npm install` during dependency deployment.

## Docker runtime

Docker is detected through the Docker CLI. Containers are started with:

- memory limit
- CPU limit
- PID limit
- dropped Linux capabilities
- `no-new-privileges`
- the server workspace mounted at `/workspace`
- an isolated container network
- allocated TCP/UDP ports published from the panel's port pool

Check availability from the panel with:

```text
GET /api/servers/runtime-options
```

For maximum isolation of untrusted bot code, use Docker mode.

## Native runtime

Native mode launches a real Linux child process in the server workspace, redirects stdin/stdout/stderr, tracks its PID, captures logs, supports graceful stop/restart/kill, and applies Linux `RLIMIT_AS` and `RLIMIT_NPROC` where supported.

Native mode cannot provide a complete security boundary around arbitrary third-party code. Disk quotas and hard CPU cgroups require Docker/cgroup-backed isolation. The API reports `native-best-effort` enforcement for native servers. Normal users are prevented from creating native servers by default (`ALLOW_NATIVE_USER_BOTS=false`); administrators can enable it when trusted workloads are intended.

## Deployments

### Upload

Use the file manager or deployment endpoint with multipart upload. ZIP archives can be uploaded and safely extracted through the file manager.

### GitHub / GitLab / HTTPS Git

Provide an HTTPS or `git@...` repository URL, branch, and optional access token. An optional SSH private key can be supplied for the Git operation. Existing checkouts use fetch/checkout/pull; fresh workspaces use a shallow clone.

API endpoint:

```text
POST /api/servers/{id}/deploy/github
```

Deployment state is stored in the database and streamed through:

```text
/ws/servers/{id}/deployment
```

## Console

Console controls:

- Start
- Stop
- Restart
- Kill
- stdin command sending
- live output
- ANSI SGR color rendering for common codes
- auto-scroll
- log clear
- log download

WebSocket:

```text
/ws/servers/{id}/console
```

The panel does not expose a general host shell to normal users. In native mode, code execution is still governed by the native runtime limitations described above.

## File manager

Supported operations include browse, create file/folder, edit, save, save-and-restart, upload, drag-and-drop upload, download, rename, copy, move, delete, search, ZIP, and safe ZIP extraction. All paths are resolved under the server workspace and rejected when they escape it.

## Environment variables

Each server has an environment manager for:

- add
- edit
- delete
- secret masking
- `.env` import
- `.env` export

Secret values are masked in the environment API. Process output is also filtered against configured environment values before persistence when possible.

## Resources and health

Per-server monitoring records:

- CPU
- RAM
- disk usage
- network RX/TX for Docker stats where available
- uptime
- PID / container
- status
- restart count
- exit code
- last crash/start/stop

WebSocket:

```text
/ws/servers/{id}/stats
```

## Auto restart

Configure:

- auto restart
- restart delay
- maximum restart attempts
- startup timeout

Crashes and automatic restarts generate web notifications and optional Discord webhook notifications.

## Ports

The panel keeps a database-backed public port pool. It checks database allocations and attempts a real socket bind before allocating an unused TCP port. The same allocation can represent TCP or UDP. Docker mode publishes allocated ports into the container.

Default pool:

```text
8001-8999
```

Admins can change the pool under Admin settings.

## Backups

Backups are stored under:

```text
backups/<server-id>/
```

Features:

- manual ZIP backup
- download
- restore
- delete
- scheduled backup action

Restore validates every archive member against the server workspace before extraction.

## Scheduled tasks

Supported actions:

- start
- stop
- restart
- backup

Schedules:

- every X minutes
- hourly
- daily
- weekly
- 5-field cron

Example cron:

```text
*/15 * * * *
```

The panel includes its own lightweight 5-field cron parser, so no extra cron Python package is required.

## Notifications / Discord

Web notifications are stored per user. Discord uses an optional webhook configured in `.env`:

```env
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/...
```

The webhook URL is never returned by the notification settings API. Enable/disable the notification preference from the Admin API.

## Users / roles / permissions

Roles:

- Owner
- Admin
- Staff
- User

Authorization is enforced server-side for server, file, console, user-management, billing, settings, and API-key actions.

User quotas include:

- maximum servers
- maximum RAM
- maximum disk
- maximum CPU allocation
- maximum ports

Server collaborators can receive:

- console
- files
- start
- stop
- restart
- settings
- resource-view permissions

## API keys

Create keys from **Account & API**. A raw API key is returned once.

Use it as:

```http
Authorization: Bearer op_xxxxxxxxx
```

The same permission system is used for API-key requests.

## Authentication and security

The panel includes:

- Argon2 password hashing
- JWT expiration
- HttpOnly access cookie
- CSRF protection for cookie-authenticated mutating requests
- login rate limiting and account locking
- role/permission checks
- input validation
- path traversal protection
- upload size limits
- command parsing without `shell=True`
- security headers
- secret masking
- audit/activity logs

For HTTPS deployments set:

```env
COOKIE_SECURE=true
TRUST_PROXY=true
```

when the reverse proxy terminates TLS and the proxy headers are trusted.

## Forgot password / SMTP

Password-reset tokens are time-limited and hashed in the database. To deliver reset emails, configure:

```env
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=username
SMTP_PASSWORD=password
SMTP_FROM=no-reply@example.com
SMTP_TLS=true
```

Without SMTP, the reset token can still be supplied directly to the reset endpoint from a trusted administration/recovery workflow.

## PostgreSQL

Set:

```env
DATABASE_URL=postgresql+psycopg://USER:PASSWORD@HOST:5432/DATABASE
```

The installer installs the PostgreSQL driver from `requirements.txt`.

Database schema setup is automatic. The update process calls `migrate.py` after dependency updates.

## Reverse proxy

### Nginx

Use `config/nginx.conf` and replace the example hostname. Keep the panel bound to `127.0.0.1:7070` when Nginx is the public entry point.

### Caddy

Use `config/Caddyfile`.

### Cloudflare Tunnel

Use `config/cloudflared.yml.example` and point the tunnel service to:

```text
http://127.0.0.1:7070
```

When the panel is only reachable through a reverse proxy/tunnel, set `HOST=127.0.0.1` and `COOKIE_SECURE=true` for an HTTPS endpoint.

## Billing-ready architecture

The basic installation is payment-free. Four seeded plans are created:

- Free
- Basic
- Pro
- Custom

Plans and subscriptions are database models. Payment providers can be added later without changing the core server runtime API. Current endpoints expose plan listing, subscription state, and administrator plan assignment.

## Updates

```bash
sudo ./update.sh
```

The updater:

1. saves a backup under `data/update-*`
2. pulls a Git checkout when the panel itself is installed from Git
3. updates Python dependencies
4. runs database initialization/migration
5. restarts the panel

User server data is never intentionally removed by the update script.

## Uninstall

```bash
sudo ./uninstall.sh
```

The uninstaller asks separately about:

- backup creation
- deleting server data/backups/database
- deleting application code

## API documentation

Interactive OpenAPI docs:

```text
/docs
/redoc
/openapi.json
```

Important API paths include:

```text
POST /api/auth/login
POST /api/auth/register
POST /api/auth/logout
GET  /api/servers
POST /api/servers
GET  /api/servers/{id}
DELETE /api/servers/{id}
POST /api/servers/{id}/start
POST /api/servers/{id}/stop
POST /api/servers/{id}/restart
POST /api/servers/{id}/kill
GET  /api/servers/{id}/logs
POST /api/servers/{id}/command
GET  /api/servers/{id}/files
POST /api/servers/{id}/upload
GET  /api/servers/{id}/resources
GET  /api/users
POST /api/users
DELETE /api/users/{id}
POST /api/keys
DELETE /api/keys/{id}
```

WebSockets:

```text
/ws/servers/{id}/console
/ws/servers/{id}/stats
/ws/servers/{id}/deployment
```

## Troubleshooting

### Port 7070 is busy

Change `PORT` in `.env` and restart. The default remains `7070`.

### systemd is unavailable

Use `./start.sh`, `./stop.sh`, and `./restart.sh`. PID state is stored in `data/panel.pid`.

### Docker is unavailable

Use Native mode for trusted workloads, or install Docker and ensure the `op-host` service account can access the Docker socket.

### A runtime version is rejected

The panel validates installed interpreters. Check:

```bash
python3 --version
which python3.11 python3.12 python3.13
node --version
npm --version
java --version
```

### Native bot cannot start under its memory limit

Increase the RAM allocation. Native mode uses Linux virtual-memory/process-count limits where supported; language runtimes can need substantial address space even when their RSS is lower.

### View logs

```bash
tail -f /opt/op-host/logs/panel.log
```

## Testing

Run:

```bash
pytest -q
```

The included suite covers authentication, server creation, lifecycle, file security, environment masking, API keys, resources, and cron calculation.
