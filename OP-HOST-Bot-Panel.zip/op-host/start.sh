#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"; PID_FILE="$APP_DIR/data/panel.pid"; LOG_FILE="$APP_DIR/logs/panel.log"
if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null || true)" = "systemd" ] && systemctl list-unit-files op-host.service >/dev/null 2>&1; then systemctl start op-host.service; echo "OP HOST service started"; exit 0; fi
if [ -f "$PID_FILE" ]; then pid=$(cat "$PID_FILE"); if kill -0 "$pid" 2>/dev/null; then echo "Already running (PID $pid)"; exit 0; fi; rm -f "$PID_FILE"; fi
mkdir -p "$APP_DIR/logs" "$APP_DIR/data"
nohup "$APP_DIR/.venv/bin/python" "$APP_DIR/app.py" >>"$LOG_FILE" 2>&1 & echo $! >"$PID_FILE"
chown "$(id -u):$(id -g)" "$PID_FILE" 2>/dev/null || true
echo "Started OP HOST (PID $(cat "$PID_FILE")) on port 7070"
