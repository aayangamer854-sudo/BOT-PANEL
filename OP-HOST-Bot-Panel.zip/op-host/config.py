"""Configuration for OP HOST Bot Panel."""
from __future__ import annotations
import logging, os
from pathlib import Path
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=str(BASE_DIR / ".env"), extra="ignore", case_sensitive=False)
    PANEL_NAME: str = "OP HOST Bot Panel"
    VERSION: str = "1.0.0"
    HOST: str = "0.0.0.0"
    PORT: int = Field(default=7070, ge=1, le=65535)
    SECRET_KEY: str = "change-me-in-production"
    SESSION_SECRET: str = "change-session-secret-in-production"
    JWT_SECRET: str = "change-jwt-secret-in-production"
    JWT_EXPIRE_MINUTES: int = 60
    SESSION_MAX_AGE: int = 3600
    COOKIE_SECURE: bool = False
    CORS_ORIGINS_RAW: str = ""
    DATABASE_URL: str = "sqlite:///./data/panel.db"
    LOG_LEVEL: str = "INFO"
    MAX_UPLOAD_MB: int = 100
    MAX_LOG_LINES: int = 5000
    PORT_RANGE_START: int = 8001
    PORT_RANGE_END: int = 8999
    SERVERS_DIR: str = "servers"
    BACKUPS_DIR: str = "backups"
    DATA_DIR: str = "data"
    LOG_DIR: str = "logs"
    ALLOW_REGISTRATION: bool = True
    ALLOW_NATIVE_USER_BOTS: bool = False
    NATIVE_BOT_USER: str = "opbot"
    NATIVE_BOT_GROUP: str = "opbot"
    DOCKER_DEFAULT_NETWORK: str = "bridge"
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = ""
    SMTP_TLS: bool = True
    RESET_TOKEN_MINUTES: int = 30
    DISCORD_WEBHOOK_URL: str = ""
    MAINTENANCE_MODE: bool = False
    TRUST_PROXY: bool = False
    RATE_LIMIT_LOGIN_ATTEMPTS: int = 8
    RATE_LIMIT_LOGIN_WINDOW_SECONDS: int = 900
    PASSWORD_MIN_LENGTH: int = 8

    @property
    def BASE_DIR(self) -> Path:
        return BASE_DIR
    @property
    def SERVERS_PATH(self) -> Path:
        return BASE_DIR / self.SERVERS_DIR
    @property
    def BACKUPS_PATH(self) -> Path:
        return BASE_DIR / self.BACKUPS_DIR
    @property
    def DATA_PATH(self) -> Path:
        return BASE_DIR / self.DATA_DIR
    @property
    def LOG_PATH(self) -> Path:
        return BASE_DIR / self.LOG_DIR
    @property
    def CORS_ORIGINS(self) -> list[str]:
        return [x.strip() for x in self.CORS_ORIGINS_RAW.split(",") if x.strip()]
    @property
    def logger(self):
        return logging.getLogger("op_host")

settings = Settings()
if "SESSION_MAX_AGE" not in os.environ:
    settings.SESSION_MAX_AGE = settings.JWT_EXPIRE_MINUTES * 60
if settings.DATABASE_URL.startswith("sqlite:///./"):
    settings.DATABASE_URL = "sqlite:///" + str((BASE_DIR / settings.DATABASE_URL.removeprefix("sqlite:///./")).resolve())
for p in (settings.DATA_PATH, settings.LOG_PATH, settings.SERVERS_PATH, settings.BACKUPS_PATH, BASE_DIR / "config"):
    p.mkdir(parents=True, exist_ok=True)
logging.basicConfig(filename=str(settings.LOG_PATH / "panel.log"), level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO), format="%(asctime)s %(levelname)s %(name)s %(message)s")
logging.getLogger("uvicorn.access").setLevel(logging.INFO)
