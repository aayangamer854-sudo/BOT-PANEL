from __future__ import annotations
import hashlib, secrets
from datetime import datetime, timedelta, timezone
import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from config import settings

ph = PasswordHasher()

def hash_password(password: str) -> str:
    return ph.hash(password)

def verify_password(password: str, password_hash: str) -> bool:
    try:
        return ph.verify(password_hash, password)
    except VerifyMismatchError:
        return False

def create_access_token(user_id: int, role: str, expires_minutes: int | None = None) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=expires_minutes or settings.JWT_EXPIRE_MINUTES)
    return jwt.encode({"sub": str(user_id), "role": role, "exp": exp, "iat": datetime.now(timezone.utc)}, settings.JWT_SECRET, algorithm="HS256")

def decode_access_token(token: str):
    return jwt.decode(token, settings.JWT_SECRET, algorithms=["HS256"])

def generate_reset_token() -> str:
    return secrets.token_urlsafe(32)

def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()

def password_meets_policy(password: str) -> bool:
    if len(password) < settings.PASSWORD_MIN_LENGTH:
        return False
    return any(c.isalpha() for c in password) and any(c.isdigit() for c in password)
