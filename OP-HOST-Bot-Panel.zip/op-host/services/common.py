from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from models.server import Server, ServerCollaborator
from services.auth_service import decode_access_token

ROLE_ORDER = {"User":1,"Staff":2,"Admin":3,"Owner":4}

def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    auth = request.headers.get("Authorization", "")
    token = auth[7:] if auth.startswith("Bearer ") else request.cookies.get("op_access")
    if not token:
        raise HTTPException(401, "Authentication required")
    if token.startswith("op_"):
        import hashlib
        from models.api_key import ApiKey
        from datetime import datetime
        key = db.query(ApiKey).filter_by(key_hash=hashlib.sha256(token.encode()).hexdigest(), is_active=True).first()
        if not key:
            raise HTTPException(401, "Invalid API key")
        key.last_used_at = datetime.utcnow(); db.commit()
        user = db.get(User, key.user_id)
    else:
        try:
            payload = decode_access_token(token)
            user_id = int(payload["sub"])
        except Exception:
            raise HTTPException(401, "Invalid or expired session")
        user = db.get(User, user_id)
    if not user or not user.is_active or user.is_locked:
        raise HTTPException(403, "Account is inactive or locked")
    return user

def require_role(*roles):
    def dep(user: User = Depends(current_user)):
        if user.role not in roles:
            raise HTTPException(403, "Insufficient permissions")
        return user
    return dep

def can_access_server(db: Session, user: User, server: Server, permission: str | None = None) -> bool:
    if ROLE_ORDER.get(user.role, 0) >= ROLE_ORDER["Staff"]:
        return True
    if server.owner_id == user.id:
        return True
    collab = db.query(ServerCollaborator).filter_by(server_id=server.id, user_id=user.id).first()
    if not collab:
        return False
    if permission and permission not in {p.strip() for p in collab.permissions.split(",") if p.strip()}:
        return False
    return True

def accessible_server(db, user, server_id, permission=None):
    server = db.get(Server, server_id)
    if not server or not can_access_server(db, user, server, permission):
        raise HTTPException(404, "Server not found")
    return server

def audit(db, user, action, request: Request, server_id=None, details=""):
    from models.activity import ActivityLog
    log = ActivityLog(user_id=user.id if user else None, server_id=server_id, action=action, details=details, ip_address=request.client.host if request.client else None)
    db.add(log); db.commit()

def json_env(db, server_id):
    from models.server import EnvironmentVariable
    rows=db.query(EnvironmentVariable).filter_by(server_id=server_id).all()
    return {r.name:r.value for r in rows}
