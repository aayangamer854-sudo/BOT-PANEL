from __future__ import annotations
import hmac, secrets, time
from collections import defaultdict, deque
from fastapi import HTTPException, Request, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from config import settings

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' ws: wss:"
        return response

_login_attempts = defaultdict(deque)

def client_ip(request: Request) -> str:
    if settings.TRUST_PROXY:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"

def login_allowed(ip: str) -> bool:
    now = time.time(); q = _login_attempts[ip]
    while q and q[0] < now - settings.RATE_LIMIT_LOGIN_WINDOW_SECONDS:
        q.popleft()
    return len(q) < settings.RATE_LIMIT_LOGIN_ATTEMPTS

def record_login_failure(ip: str):
    _login_attempts[ip].append(time.time())

def csrf_token(request: Request) -> str:
    token = request.cookies.get("op_csrf")
    if not token:
        token = secrets.token_urlsafe(24)
        request.state.new_csrf = token
    return token

def require_csrf(request: Request):
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return
    expected = request.cookies.get("op_csrf")
    provided = request.headers.get("X-CSRF-Token")
    if not expected or not provided or not hmac.compare_digest(expected, provided):
        raise HTTPException(status_code=403, detail="CSRF validation failed")
