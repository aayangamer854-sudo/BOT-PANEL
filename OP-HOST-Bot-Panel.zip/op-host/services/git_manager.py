from __future__ import annotations
import os, subprocess, tempfile, urllib.parse
from pathlib import Path
class GitManager:
    def _validate(self,url):
        if url.startswith("git@"):
            return url
        p=urllib.parse.urlparse(url)
        if p.scheme!="https" or not p.netloc: raise ValueError("Only HTTPS Git repositories or git@ SSH URLs are allowed")
        return url
    def deploy(self, server, url, branch="main", token="", ssh_key=""):
        url=self._validate(url); cwd=Path(server.working_directory)
        askpass=None; keyfile=None; env=os.environ.copy()
        try:
            if ssh_key:
                fd,keyfile=tempfile.mkstemp(prefix="opgit-key-",text=True); os.write(fd,ssh_key.encode()); os.close(fd); os.chmod(keyfile,0o600); env["GIT_SSH_COMMAND"]=f"ssh -i {keyfile} -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new"
            if token and url.startswith("https://"):
                fd, askpass=tempfile.mkstemp(prefix="opgit-",text=True); os.write(fd,b'#!/bin/sh\necho "$GIT_TOKEN"\n'); os.close(fd); os.chmod(askpass,0o700); env["GIT_ASKPASS"]=askpass; env["GIT_TERMINAL_PROMPT"]="0"; env["GIT_TOKEN"]=token
            if (cwd/".git").exists(): subprocess.run(["git","fetch","--all","--prune"],cwd=cwd,env=env,check=True,capture_output=True,text=True,timeout=300); subprocess.run(["git","checkout",branch],cwd=cwd,env=env,check=True,capture_output=True,text=True,timeout=60); p=subprocess.run(["git","pull","origin",branch],cwd=cwd,env=env,check=True,capture_output=True,text=True,timeout=300); return p.stdout[-4000:]
            for child in cwd.iterdir():
                if child.name != ".git":
                    if child.is_dir(): __import__('shutil').rmtree(child)
                    else: child.unlink()
            p=subprocess.run(["git","clone","--branch",branch,"--depth","1",url,str(cwd)],env=env,check=True,capture_output=True,text=True,timeout=600)
            (cwd/".op-host").write_text("workspace managed by OP HOST\n")
            return p.stdout[-4000:]
        finally:
            if askpass:
                try: os.unlink(askpass)
                except: pass
            if keyfile:
                try: os.unlink(keyfile)
                except: pass
git_manager=GitManager()
