from __future__ import annotations
from datetime import datetime, timedelta

FIELD_RANGES=[(0,59),(0,23),(1,31),(1,12),(0,6)]

def parse_field(expr,lo,hi):
    vals=set()
    for item in expr.split(','):
        item=item.strip()
        if not item: raise ValueError('empty cron field')
        if item=='*': vals.update(range(lo,hi+1)); continue
        step=1
        if '/' in item:
            base,step_s=item.split('/',1); step=int(step_s)
            if step<1: raise ValueError('invalid cron step')
        else: base=item
        if base=='*': start,end=lo,hi
        elif '-' in base:
            a,b=base.split('-',1); start,end=int(a),int(b)
        else:
            n=int(base); start=end=n
        if start<lo or end>hi or start>end: raise ValueError('cron value outside range')
        vals.update(range(start,end+1,step))
    return vals

def parse(expr):
    parts=expr.strip().split()
    if len(parts)!=5: raise ValueError('Cron expression must have 5 fields')
    return [parse_field(parts[i],*FIELD_RANGES[i]) for i in range(5)]

def matches(dt,sets):
    # Day-of-month/day-of-week follow standard cron OR behavior when both are restricted.
    minute,hour,dom,month,dow=dt.minute,dt.hour,dt.day,dt.month,(dt.weekday()+1)%7
    minute_set,hour_set,dom_set,month_set,dow_set=sets
    if minute not in minute_set or hour not in hour_set or month not in month_set: return False
    dom_any=len(dom_set)==31 and min(dom_set)==1 and max(dom_set)==31
    dow_any=len(dow_set)==7 and min(dow_set)==0 and max(dow_set)==6
    dom_ok=dom in dom_set; dow_ok=dow in dow_set
    return (dom_ok and dow_ok) if dom_any or dow_any else (dom_ok or dow_ok)

def next_run(expr,base):
    sets=parse(expr)
    dt=(base+timedelta(minutes=1)).replace(second=0,microsecond=0)
    limit=366*24*60
    for _ in range(limit):
        if matches(dt,sets): return dt
        dt+=timedelta(minutes=1)
    raise ValueError('No matching cron time found within one year')
