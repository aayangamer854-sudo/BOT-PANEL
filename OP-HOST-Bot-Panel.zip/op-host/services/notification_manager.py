from __future__ import annotations
import json, smtplib, urllib.request
from email.message import EmailMessage
from models.server import Notification
from config import settings
class NotificationManager:
    def create(self,db,user_id,title,message,level="info",discord=True):
        db.add(Notification(user_id=user_id,title=title,message=message,level=level)); db.commit()
        if discord and settings.DISCORD_WEBHOOK_URL: self.discord(title,message)
    def discord(self,title,message):
        data=json.dumps({"embeds":[{"title":title,"description":message}]}).encode(); req=urllib.request.Request(settings.DISCORD_WEBHOOK_URL,data=data,headers={"Content-Type":"application/json"});
        try: urllib.request.urlopen(req,timeout=10).read()
        except Exception as e: settings.logger.warning("Discord webhook failed: %s",e)
    def email(self,to,subject,body):
        if not (settings.SMTP_HOST and settings.SMTP_FROM): return False
        msg=EmailMessage(); msg["From"]=settings.SMTP_FROM; msg["To"]=to; msg["Subject"]=subject; msg.set_content(body)
        with smtplib.SMTP(settings.SMTP_HOST,settings.SMTP_PORT,timeout=15) as s:
            if settings.SMTP_TLS: s.starttls()
            if settings.SMTP_USER: s.login(settings.SMTP_USER,settings.SMTP_PASSWORD)
            s.send_message(msg)
        return True
notification_manager=NotificationManager()
