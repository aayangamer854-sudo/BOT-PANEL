from __future__ import annotations
import threading, time
from datetime import datetime, timedelta
from services.cron import next_run
from database import SessionLocal
from models.server import ScheduledTask, Server
from services.process_manager import process_manager
from services.docker_manager import docker_manager
class SchedulerService:
    def __init__(self): self.stop_evt=threading.Event(); self.thread=None
    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.stop_evt.clear(); self.thread=threading.Thread(target=self.loop,daemon=True); self.thread.start()
    def stop(self): self.stop_evt.set()
    def calc_next(self,task,base):
        if task.schedule_type=="interval": return base+timedelta(minutes=max(1,int(task.expression)))
        if task.schedule_type=="hourly": return base+timedelta(hours=1)
        if task.schedule_type=="daily": return base+timedelta(days=1)
        if task.schedule_type=="weekly": return base+timedelta(weeks=1)
        return next_run(task.expression,base)
    def loop(self):
        while not self.stop_evt.is_set():
            db=SessionLocal(); now=datetime.utcnow()
            try:
                for task in db.query(ScheduledTask).filter_by(enabled=True).all():
                    if task.next_run_at and task.next_run_at <= now:
                        s=db.get(Server,task.server_id)
                        try:
                            if s:
                                if task.action=="start": (docker_manager.start(db,s,__import__('services.common',fromlist=['json_env']).json_env(db,s.id)) if s.runtime_mode=="docker" else process_manager.start(db,s))
                                elif task.action=="stop": (docker_manager.stop(s) if s.runtime_mode=="docker" else process_manager.stop(db,s))
                                elif task.action=="restart": (docker_manager.restart(s) if s.runtime_mode=="docker" else process_manager.restart(db,s))
                                elif task.action=="backup": from services.backup_manager import backup_manager; backup_manager.create(s,f"scheduled-{task.id}-{int(now.timestamp())}.zip")
                        except Exception as e: task.last_run_at=now
                        task.next_run_at=self.calc_next(task,now); task.last_run_at=now; db.commit()
            finally: db.close()
            self.stop_evt.wait(10)
scheduler_service=SchedulerService()
