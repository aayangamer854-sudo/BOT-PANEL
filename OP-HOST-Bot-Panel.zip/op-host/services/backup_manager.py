from __future__ import annotations
import shutil, zipfile
from pathlib import Path
from config import settings
from fastapi import HTTPException
class BackupManager:
    def create(self, server, filename):
        safe=Path(filename).name
        if not safe.endswith(".zip"): safe += ".zip"
        target=settings.BACKUPS_PATH / server.id; target.mkdir(parents=True,exist_ok=True); out=target / safe
        root=Path(server.working_directory).resolve()
        with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
            for p in root.rglob("*"):
                if p.is_file(): z.write(p,p.relative_to(root))
        return out
    def restore(self, server, archive):
        archive=Path(archive).resolve(); root=Path(server.working_directory).resolve()
        if not zipfile.is_zipfile(archive): raise HTTPException(400,"Invalid backup archive")
        with zipfile.ZipFile(archive) as z:
            for m in z.infolist():
                dest=(root / m.filename).resolve()
                try: dest.relative_to(root)
                except ValueError: raise HTTPException(400,"Unsafe backup archive")
            z.extractall(root)
backup_manager=BackupManager()
