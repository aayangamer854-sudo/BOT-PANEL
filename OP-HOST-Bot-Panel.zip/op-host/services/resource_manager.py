from __future__ import annotations
import os, shutil, threading, time, psutil
from datetime import datetime
from models.server import Server, ServerResource
from database import SessionLocal
from config import settings
from services.process_manager import process_manager
from services.docker_manager import docker_manager
class ResourceService:
    def __init__(self): self.stop_evt=threading.Event(); self.thread=None
    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.stop_evt.clear(); self.thread=threading.Thread(target=self.loop,daemon=True); self.thread.start()
    def stop(self): self.stop_evt.set()
    def loop(self):
        while not self.stop_evt.is_set():
            db=SessionLocal()
            try:
                for s in db.query(Server).all(): self.sample(db,s)
            except Exception: db.rollback()
            finally: db.close()
            self.stop_evt.wait(5)
    def sample(self,db,s):
        res=db.query(ServerResource).filter_by(server_id=s.id).first() or ServerResource(server_id=s.id); data={}
        if s.runtime_mode=="docker" and docker_manager.available():
            state=docker_manager.state(s)
            data=docker_manager.stats(s) if state=="running" else {}
            if state in {"exited","dead"} and s.status=="RUNNING":
                s.status="CRASHED"; s.pid=None; s.exit_code=1; s.last_crash_at=datetime.utcnow();
                if s.auto_restart and s.restart_count < s.max_restarts:
                    s.restart_count += 1; db.commit()
                    try: docker_manager.start(db,s,__import__('services.common',fromlist=['json_env']).json_env(db,s.id))
                    except Exception: s.status="ERROR"
                db.commit()
            elif state=="running": s.status="RUNNING"; db.commit()
            elif state=="missing" and s.status not in {"STOPPED","ERROR"}: s.status="STOPPED"; db.commit()
        elif s.pid:
            try:
                p=psutil.Process(s.pid); data={"cpu_percent":p.cpu_percent(interval=0.05),"ram_mb":p.memory_info().rss/1024/1024,"network_rx":0,"network_tx":0,"uptime_seconds":int(time.time()-p.create_time())}
            except (psutil.NoSuchProcess,psutil.AccessDenied): pass
        try:
            disk=0
            for base,dirs,files in os.walk(s.working_directory):
                for fn in files:
                    try: disk += os.path.getsize(os.path.join(base,fn)) / 1024 / 1024
                    except OSError: pass
        except: disk=0
        res.cpu_percent=float(data.get("cpu_percent",0)); res.ram_mb=float(data.get("ram_mb",0)); res.disk_mb=disk; res.network_rx=int(data.get("network_rx",0)); res.network_tx=int(data.get("network_tx",0)); res.uptime_seconds=int(data.get("uptime_seconds",0)); res.sampled_at=datetime.utcnow(); db.add(res); db.commit()
resource_service=ResourceService()
