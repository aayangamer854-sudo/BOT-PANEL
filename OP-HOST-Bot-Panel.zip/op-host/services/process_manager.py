from __future__ import annotations
import os, shlex, shutil, signal, subprocess, threading, time, resource
from datetime import datetime
from pathlib import Path
from collections import deque
from sqlalchemy.orm import Session
from config import settings
from models.server import Server, ServerLog
from services.common import json_env

class ProcessManager:
    def __init__(self):
        self.procs={}; self.lock=threading.RLock(); self.buffers={}
    def _command(self, server: Server):
        try: parts=shlex.split(server.startup_command)
        except ValueError as e: raise ValueError(f"Invalid startup command: {e}")
        if not parts: raise ValueError("Startup command is empty")
        exe=parts[0]
        resolved=shutil.which(exe) if not os.path.isabs(exe) else exe
        if not resolved or not os.access(resolved,os.X_OK): raise ValueError(f"Executable not found: {exe}")
        # Prevent direct absolute execution outside a small runtime allowlist.
        allowed={"python","python3","node","npm","bun","java","git","pip","pip3"}
        base=os.path.basename(resolved)
        if base not in allowed and not Path(resolved).is_relative_to(Path(server.working_directory).resolve()):
            raise ValueError(f"Executable is not an allowed runtime: {base}")
        parts[0]=resolved
        return parts
    def start(self, db: Session, server: Server):
        with self.lock:
            if server.id in self.procs and self.procs[server.id].poll() is None: return
            if server.runtime_mode=="native" and not settings.ALLOW_NATIVE_USER_BOTS and server.owner_id is not None:
                # Admin/staff can use native; ordinary user native is rejected by API before this point.
                pass
            Path(server.working_directory).mkdir(parents=True,exist_ok=True)
            cmd=self._command(server)
            env=os.environ.copy(); env.update(json_env(db,server.id)); env["OP_HOST_SERVER_ID"]=server.id
            def preexec():
                os.setsid()
                try:
                    resource.setrlimit(resource.RLIMIT_AS,(server.ram_limit_mb*1024*1024,server.ram_limit_mb*1024*1024))
                except Exception: pass
                try:
                    resource.setrlimit(resource.RLIMIT_NPROC,(server.process_limit,server.process_limit))
                except Exception: pass
            proc=subprocess.Popen(cmd,cwd=server.working_directory,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=False,preexec_fn=preexec if os.name=='posix' else None)
            self.procs[server.id]=proc; self.buffers.setdefault(server.id,deque(maxlen=settings.MAX_LOG_LINES))
            server.status="STARTING"; server.pid=proc.pid; server.last_start_at=datetime.utcnow(); server.exit_code=None
            db.add(server); db.commit()
            threading.Thread(target=self._reader,args=(db.bind,server.id,proc),daemon=True).start()
            threading.Thread(target=self._watcher,args=(db.bind,server.id,proc),daemon=True).start()
            threading.Thread(target=self._startup_timer,args=(server.id,server.startup_timeout),daemon=True).start()
    def _startup_timer(self,sid,timeout_seconds):
        time.sleep(max(1,timeout_seconds))
        from database import SessionLocal
        db=SessionLocal()
        try:
            server=db.get(Server,sid)
            with self.lock: proc=self.procs.get(sid)
            if server and server.status=="STARTING" and proc and proc.poll() is None:
                server.status="RUNNING"; db.commit()
        finally: db.close()
    def _reader(self, bind, sid, proc):
        from database import SessionLocal
        for line in proc.stdout:
            line=line.rstrip("\n")
            dbmask=SessionLocal()
            try: secrets=list(json_env(dbmask,sid).values())
            except Exception: secrets=[]
            finally: dbmask.close()
            for secret in secrets:
                if secret and len(secret)>=3: line=line.replace(secret,"********")
            with self.lock: self.buffers.setdefault(sid,deque(maxlen=settings.MAX_LOG_LINES)).append(line)
            db=SessionLocal()
            try:
                db.add(ServerLog(server_id=sid,line=line)); db.commit()
            except Exception: db.rollback()
            finally: db.close()
        try: proc.stdout.close()
        except Exception: pass
    def _watcher(self, bind, sid, proc):
        rc=proc.wait()
        from database import SessionLocal
        db=SessionLocal()
        try:
            server=db.get(Server,sid)
            if not server: return
            server.exit_code=rc; server.pid=None; server.last_stop_at=datetime.utcnow()
            if rc==0: server.status="STOPPED"
            else:
                server.status="CRASHED"; server.last_crash_at=datetime.utcnow();
                from services.notification_manager import notification_manager
                notification_manager.create(db,server.owner_id,"Server crashed",f"{server.name} exited with code {rc}","error")
                if server.auto_restart and server.restart_count < server.max_restarts:
                    server.restart_count += 1; db.commit(); time.sleep(max(1,server.restart_delay))
                    try:
                        self.start(db,server)
                        notification_manager.create(db,server.owner_id,"Server restarted",f"{server.name} was automatically restarted")
                    except Exception as e:
                        server.status="ERROR"; db.commit()
                else: db.commit()
            db.add(server); db.commit()
        finally: db.close()
        with self.lock: self.procs.pop(sid,None)
    def stop(self, db, server, force=False):
        with self.lock: proc=self.procs.get(server.id)
        if not proc or proc.poll() is not None:
            server.status="STOPPED"; server.pid=None; db.commit(); return
        server.status="STOPPING"; db.commit()
        try:
            os.killpg(proc.pid, signal.SIGKILL if force else signal.SIGTERM)
            if not force: 
                try: proc.wait(timeout=10)
                except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError: pass
        server.pid=None; server.status="STOPPED"; server.last_stop_at=datetime.utcnow(); db.commit()
    def restart(self, db, server):
        self.stop(db,server); time.sleep(0.5); server.restart_count=0; db.commit(); self.start(db,server)
    def send(self, server, command):
        with self.lock: proc=self.procs.get(server.id)
        if not proc or proc.poll() is not None or not proc.stdin: raise RuntimeError("Server is not running")
        proc.stdin.write(command+"\n"); proc.stdin.flush()
    def logs(self, db, server, limit=300):
        rows=db.query(ServerLog).filter_by(server_id=server.id).order_by(ServerLog.id.desc()).limit(limit).all()
        return [x.line for x in reversed(rows)]
    def status(self, server):
        with self.lock: p=self.procs.get(server.id)
        if p and p.poll() is None: return "RUNNING"
        return server.status or "STOPPED"
process_manager=ProcessManager()
