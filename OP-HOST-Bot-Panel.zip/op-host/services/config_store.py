from database import SessionLocal
from models.server import Settings

def get_setting(db,key,default=None):
    row=db.query(Settings).filter_by(key=key).first()
    return default if not row else row.value

def set_setting(db,key,value):
    row=db.query(Settings).filter_by(key=key).first() or Settings(key=key)
    row.value=str(value); db.add(row); db.commit(); return row
