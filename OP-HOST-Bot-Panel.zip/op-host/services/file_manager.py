from __future__ import annotations
import os, shutil, zipfile, tempfile
from pathlib import Path
from datetime import datetime
from fastapi import HTTPException, UploadFile
from config import settings

class FileManager:
    def __init__(self, server):
        self.server=server
        self.root=Path(server.working_directory).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
    def safe(self, rel: str=".") -> Path:
        rel=rel or "."
        p=(self.root / rel).resolve()
        try: p.relative_to(self.root)
        except ValueError: raise HTTPException(400,"Invalid path")
        return p
    def list(self, rel="."):
        p=self.safe(rel)
        if not p.is_dir(): raise HTTPException(400,"Not a directory")
        out=[]
        for x in sorted(p.iterdir(), key=lambda z:(not z.is_dir(), z.name.lower())):
            st=x.stat()
            out.append({"name":x.name,"path":str(x.relative_to(self.root)),"is_dir":x.is_dir(),"size":st.st_size if x.is_file() else None,"modified_at":datetime.fromtimestamp(st.st_mtime).isoformat(),"permissions":oct(st.st_mode & 0o777)})
        return out
    def read_text(self, rel):
        p=self.safe(rel)
        if not p.is_file(): raise HTTPException(400,"Not a file")
        if p.stat().st_size>5*1024*1024: raise HTTPException(413,"File too large to edit")
        try: return p.read_text(encoding="utf-8")
        except UnicodeDecodeError: raise HTTPException(415,"Binary file")
    def write_text(self, rel, content):
        p=self.safe(rel)
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(content,encoding="utf-8")
    def create_file(self, rel):
        p=self.safe(rel)
        p.parent.mkdir(parents=True,exist_ok=True)
        p.touch(exist_ok=False)
    def mkdir(self, rel): self.safe(rel).mkdir(parents=True,exist_ok=False)
    def delete(self, rel):
        p=self.safe(rel)
        if p == self.root: raise HTTPException(400,"Cannot delete workspace")
        if p.is_dir(): shutil.rmtree(p)
        elif p.exists(): p.unlink()
        else: raise HTTPException(404,"Path not found")
    def rename(self, rel, new_name):
        p=self.safe(rel); target=p.parent / new_name
        target=self.safe(str(target.relative_to(self.root)))
        p.rename(target)
    def move(self, rel, destination):
        p=self.safe(rel); d=self.safe(destination); d.mkdir(parents=True,exist_ok=True) if destination.endswith("/") else None
        target=d / p.name if d.is_dir() else d
        target=self.safe(str(target.relative_to(self.root))); p.rename(target)
    def copy(self, rel, destination):
        p=self.safe(rel); d=self.safe(destination)
        target=d / p.name if d.is_dir() else d
        target=self.safe(str(target.relative_to(self.root)))
        if p.is_dir(): shutil.copytree(p,target,dirs_exist_ok=True)
        else: shutil.copy2(p,target)
    def zip(self, rel="."):
        source=self.safe(rel); name=f"backup-{source.name if source.name else self.server.id}.zip"; out=self.safe(name)
        base=source if source.is_dir() else source.parent
        with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
            if source.is_dir():
                for f in source.rglob("*"):
                    if f == out: continue
                    z.write(f, f.relative_to(base))
            else: z.write(source, source.name)
        return out
    def unzip(self, rel):
        zpath=self.safe(rel)
        if not zipfile.is_zipfile(zpath): raise HTTPException(400,"Not a zip file")
        with zipfile.ZipFile(zpath) as z:
            for member in z.infolist():
                target=self.safe(member.filename)
                if member.filename.endswith("/"): target.mkdir(parents=True,exist_ok=True)
                else:
                    target.parent.mkdir(parents=True,exist_ok=True)
                    with z.open(member) as src, open(target,"wb") as dst: shutil.copyfileobj(src,dst)
    def search(self, query, rel="."):
        q=query.lower(); base=self.safe(rel); matches=[]
        for p in base.rglob("*"):
            if q in p.name.lower(): matches.append({"path":str(p.relative_to(self.root)),"is_dir":p.is_dir()})
            if len(matches)>=500: break
        return matches
