from __future__ import annotations
import json, os, shutil, subprocess, time
from models.server import Port
class DockerManager:
    def available(self): return bool(shutil.which("docker"))
    def _run(self, args, timeout=120, check=True):
        p=subprocess.run(["docker",*args],capture_output=True,text=True,timeout=timeout)
        if check and p.returncode: raise RuntimeError(p.stderr.strip() or "Docker command failed")
        return p
    def image_for(self, runtime, version):
        if runtime=="Python": return f"python:{version if version and version!='latest' else '3.13'}-slim"
        if runtime=="Node.js": return f"node:{version if version and version!='latest' else '22'}-slim"
        if runtime=="Bun": return "oven/bun:latest"
        if runtime=="Java": return "eclipse-temurin:21-jre"
        return "alpine:3.20"
    def start(self, db, server, env):
        if not self.available(): raise RuntimeError("Docker is not installed or unavailable")
        if server.container_id:
            self.stop(server,force=True)
            self._run(["rm","-f",server.container_id],timeout=30,check=False)
            server.container_id=None
        image=self.image_for(server.runtime,server.version)
        self._run(["pull",image],timeout=600)
        name=f"op-host-{server.id[:20]}"
        args=["run","-d","-i","--name",name,"--init","--pids-limit",str(server.process_limit or 64),"--memory",f"{server.ram_limit_mb}m","--cpus",str(max(0.1,server.cpu_limit/100)),"--cap-drop","ALL","--security-opt","no-new-privileges","-v",f"{server.working_directory}:/workspace","-w","/workspace","--network", "bridge"]
        for port in db.query(Port).filter_by(server_id=server.id,is_active=True).all():
            proto=port.protocol.lower() if port.protocol.upper() in {"TCP","UDP"} else "tcp"
            args += ["-p",f"{port.public_port}:{port.internal_port}/{proto}"]
        for k,v in env.items(): args += ["-e",f"{k}={v}"]
        args += [image,"/bin/sh","-lc",server.startup_command]
        out=self._run(args,timeout=120).stdout.strip(); server.container_id=out; server.status="RUNNING"; db.commit()
    def state(self,server):
        if not server.container_id: return "STOPPED"
        p=self._run(["inspect","-f","{{.State.Status}}",server.container_id],timeout=15,check=False)
        return p.stdout.strip() or "missing"
    def stop(self,server,force=False):
        if not server.container_id: return
        cmd="kill" if force else "stop"; self._run([cmd,server.container_id],timeout=30,check=False)
    def restart(self,server):
        if server.container_id: self._run(["restart",server.container_id],timeout=30)
    def kill(self,server): self.stop(server,force=True)
    def send(self, server, command):
        if not server.container_id: raise RuntimeError("Container is not running")
        p=subprocess.run(["docker","exec","-i",server.container_id,"/bin/sh","-c","cat >/proc/1/fd/0"],input=command+"\n",capture_output=True,text=True,timeout=15)
        if p.returncode: raise RuntimeError(p.stderr.strip() or "Failed to send command")
    def logs(self,server,tail=300):
        if not server.container_id: return []
        out=self._run(["logs","--tail",str(tail),server.container_id],timeout=30,check=False).stdout
        return out.splitlines()
    def stats(self,server):
        if not server.container_id: return {}
        p=self._run(["stats","--no-stream","--format","{{json .}}",server.container_id],timeout=30,check=False)
        if not p.stdout.strip(): return {}
        try:
            d=json.loads(p.stdout.strip().splitlines()[-1])
            def pct(v):
                try:return float(v.replace("%",""))
                except:return 0
            def mem(v):
                n=float(v.split('/')[0].strip().split()[0]); unit=v.split('/')[0].strip().split()[1].upper() if len(v.split('/')[0].strip().split())>1 else 'MB';
                return n*(1024 if unit=='GB' else 1)
            rx=tx=0
            try:
                net=d.get("NetIO","0B / 0B").split("/")
                def parse_net(x):
                    x=x.strip().upper(); mult=1
                    if x.endswith("KB"): mult=1024; x=x[:-2]
                    elif x.endswith("MB"): mult=1024**2; x=x[:-2]
                    elif x.endswith("GB"): mult=1024**3; x=x[:-2]
                    elif x.endswith("B"): x=x[:-1]
                    return int(float(x.strip())*mult)
                if len(net)==2: rx,tx=parse_net(net[0]),parse_net(net[1])
            except: pass
            return {"cpu_percent":pct(d.get("CPUPerc","0")),"ram_mb":mem(d.get("MemUsage","0 MB / 0 MB")),"network_rx":rx,"network_tx":tx}
        except Exception:return {}
docker_manager=DockerManager()
