from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from models.backup import Backup
from services.common import current_user, accessible_server, audit
from services.backup_manager import backup_manager
from config import settings
router=APIRouter()
class BackupIn(BaseModel): name:str='manual'
@router.get('/{server_id}/backups')
def backups(server_id,user=Depends(current_user),db=Depends(get_db)):
 s=accessible_server(db,user,server_id,'files'); return [{'id':b.id,'filename':b.filename,'size':b.size,'created_at':b.created_at} for b in db.query(Backup).filter_by(server_id=s.id).order_by(Backup.id.desc()).all()]
@router.post('/{server_id}/backups',status_code=201)
def create_backup(server_id,payload:BackupIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files')
 p=backup_manager.create(s,payload.name); b=Backup(server_id=s.id,filename=p.name,path=str(p),size=p.stat().st_size); db.add(b); db.commit(); audit(db,user,'backup_create',request,s.id); return {'id':b.id,'filename':b.filename,'size':b.size}
@router.get('/{server_id}/backups/{backup_id}/download')
def download_backup(server_id,backup_id,user=Depends(current_user),db=Depends(get_db)):
 s=accessible_server(db,user,server_id,'files'); b=db.query(Backup).filter_by(id=backup_id,server_id=s.id).first();
 if not b or not __import__('pathlib').Path(b.path).is_file(): raise HTTPException(404,'Backup not found')
 return FileResponse(b.path,filename=b.filename)
@router.post('/{server_id}/backups/{backup_id}/restore')
def restore_backup(server_id,backup_id,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); b=db.query(Backup).filter_by(id=backup_id,server_id=s.id).first();
 if not b: raise HTTPException(404,'Backup not found')
 backup_manager.restore(s,b.path); audit(db,user,'backup_restore',request,s.id); return {'message':'Backup restored'}
@router.delete('/{server_id}/backups/{backup_id}')
def delete_backup(server_id,backup_id,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); b=db.query(Backup).filter_by(id=backup_id,server_id=s.id).first();
 if not b: raise HTTPException(404,'Backup not found')
 try: __import__('pathlib').Path(b.path).unlink(missing_ok=True)
 except: pass
 db.delete(b); db.commit(); audit(db,user,'backup_delete',request,s.id); return {'message':'Backup deleted'}
