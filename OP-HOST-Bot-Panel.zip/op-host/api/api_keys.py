from __future__ import annotations
import hashlib,secrets
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from database import get_db
from models.api_key import ApiKey
from models.user import User
from services.common import current_user, audit
router=APIRouter()
class KeyIn(BaseModel): name:str=Field(min_length=1,max_length=128)
def hash_key(k): return hashlib.sha256(k.encode()).hexdigest()
@router.get('')
def list_keys(user=Depends(current_user),db=Depends(get_db)):
 return [{'id':k.id,'name':k.name,'prefix':k.prefix,'last_used_at':k.last_used_at,'created_at':k.created_at,'is_active':k.is_active} for k in db.query(ApiKey).filter_by(user_id=user.id).order_by(ApiKey.id.desc()).all()]
@router.post('',status_code=201)
def create_key(payload:KeyIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); raw='op_'+secrets.token_urlsafe(36); k=ApiKey(user_id=user.id,name=payload.name,key_hash=hash_key(raw),prefix=raw[:10]); db.add(k); db.commit(); audit(db,user,'api_key_create',request); return {'id':k.id,'name':k.name,'token':raw}
@router.delete('/{key_id}')
def delete_key(key_id,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); k=db.query(ApiKey).filter_by(id=key_id,user_id=user.id).first();
 if not k: raise HTTPException(404,'API key not found')
 k.is_active=False; db.commit(); audit(db,user,'api_key_revoke',request); return {'message':'API key revoked'}

def api_key_user(authorization,db):
 if not authorization.startswith('Bearer op_'): return None
 raw=authorization[7:]; k=db.query(ApiKey).filter_by(key_hash=hash_key(raw),is_active=True).first()
 if not k: return None
 from datetime import datetime
 k.last_used_at=datetime.utcnow(); db.commit(); return db.get(User,k.user_id)
