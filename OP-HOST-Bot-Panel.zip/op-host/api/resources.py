from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
from services.common import current_user, accessible_server
from models.server import ServerResource
router=APIRouter()
@router.get('/{server_id}/resources')
def resources(server_id,user=Depends(current_user),db=Depends(get_db)):
 s=accessible_server(db,user,server_id,'view_resources'); r=db.query(ServerResource).filter_by(server_id=s.id).first(); return {'cpu_percent':r.cpu_percent if r else 0,'ram_mb':r.ram_mb if r else 0,'disk_mb':r.disk_mb if r else 0,'network_rx':r.network_rx if r else 0,'network_tx':r.network_tx if r else 0,'uptime_seconds':r.uptime_seconds if r else 0,'status':s.status,'enforcement':'docker-cgroups' if s.runtime_mode=='docker' else 'native-best-effort'}
