from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from models.server import Server
from services.common import current_user, require_role, audit
from services.auth_service import hash_password, password_meets_policy
router=APIRouter()
class UserCreate(BaseModel): username:str=Field(min_length=3,max_length=64); email:EmailStr; password:str; role:str='User'; max_servers:int=3; max_ram_mb:int=2048; max_disk_mb:int=10240; max_cpu_percent:int=200; max_ports:int=5
class UserUpdate(BaseModel): role:str|None=None; is_active:bool|None=None; password:str|None=None; max_servers:int|None=None; max_ram_mb:int|None=None; max_disk_mb:int|None=None; max_cpu_percent:int|None=None; max_ports:int|None=None
@router.get('')
def users(user=Depends(require_role('Owner','Admin','Staff')),db=Depends(get_db)):
 return [{'id':u.id,'username':u.username,'email':u.email,'role':u.role,'is_active':u.is_active,'is_locked':u.is_locked,'limits':{'max_servers':u.max_servers,'max_ram_mb':u.max_ram_mb,'max_disk_mb':u.max_disk_mb,'max_cpu_percent':u.max_cpu_percent,'max_ports':u.max_ports},'created_at':u.created_at} for u in db.query(User).order_by(User.id.desc()).all()]
@router.post('',status_code=201)
def create_user(payload:UserCreate,request:Request,user=Depends(require_role('Owner','Admin')),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request)
 if payload.role not in {'User','Staff','Admin'}: raise HTTPException(422,'Invalid role')
 if not password_meets_policy(payload.password): raise HTTPException(422,'Password does not meet policy')
 if db.query(User).filter((User.username==payload.username)|(User.email==str(payload.email).lower())).first(): raise HTTPException(409,'User already exists')
 u=User(username=payload.username,email=str(payload.email).lower(),password_hash=hash_password(payload.password),role=payload.role,max_servers=payload.max_servers,max_ram_mb=payload.max_ram_mb,max_disk_mb=payload.max_disk_mb,max_cpu_percent=payload.max_cpu_percent,max_ports=payload.max_ports); db.add(u); db.commit(); db.refresh(u); audit(db,user,'user_create',request,details=u.username); return {'id':u.id,'username':u.username}
@router.patch('/{user_id}')
def update_user(user_id,payload:UserUpdate,request:Request,user=Depends(require_role('Owner','Admin')),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); u=db.get(User,user_id)
 if not u: raise HTTPException(404,'User not found')
 if payload.role is not None: u.role=payload.role
 if payload.is_active is not None: u.is_active=payload.is_active
 if payload.password is not None:
  if not password_meets_policy(payload.password): raise HTTPException(422,'Password does not meet policy')
  u.password_hash=hash_password(payload.password)
 for name in ('max_servers','max_ram_mb','max_disk_mb','max_cpu_percent','max_ports'):
  val=getattr(payload,name)
  if val is not None: setattr(u,name,max(0,val))
 db.commit(); audit(db,user,'user_update',request,details=str(user_id)); return {'message':'User updated'}
@router.post('/{user_id}/unlock')
def unlock(user_id,request:Request,user=Depends(require_role('Owner','Admin')),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); u=db.get(User,user_id)
 if not u: raise HTTPException(404,'User not found')
 u.is_locked=False; u.failed_login_attempts=0; db.commit(); return {'message':'User unlocked'}
@router.delete('/{user_id}')
def delete_user(user_id,request:Request,user=Depends(require_role('Owner')),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); u=db.get(User,user_id)
 if not u: raise HTTPException(404,'User not found')
 if u.id==user.id: raise HTTPException(400,'Cannot delete yourself')
 if u.role=='Owner': raise HTTPException(403,'Cannot delete owner')
 db.delete(u); db.commit(); audit(db,user,'user_delete',request,details=str(user_id)); return {'message':'User deleted'}
