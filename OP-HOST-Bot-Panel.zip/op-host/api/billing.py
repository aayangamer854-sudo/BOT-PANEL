from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from database import get_db
from models.user import User
from models.billing import Plan, Subscription
from services.common import current_user, require_role, audit
router=APIRouter()
class PlanIn(BaseModel): name:str=Field(min_length=2,max_length=64); ram_mb:int=Field(ge=128); cpu_percent:int=Field(ge=1); disk_mb:int=Field(ge=256); max_servers:int=Field(ge=0); max_ports:int=Field(ge=0); enabled:bool=True
@router.get('/plans')
def plans(db=Depends(get_db),user=Depends(current_user)):
    return [{'id':p.id,'name':p.name,'ram_mb':p.ram_mb,'cpu_percent':p.cpu_percent,'disk_mb':p.disk_mb,'max_servers':p.max_servers,'max_ports':p.max_ports,'enabled':p.enabled} for p in db.query(Plan).filter_by(enabled=True).all()]
@router.get('/subscription')
def subscription(user=Depends(current_user),db=Depends(get_db)):
    s=db.query(Subscription).filter_by(user_id=user.id).first(); p=db.get(Plan,s.plan_id) if s else None
    return {'plan':({'id':p.id,'name':p.name,'ram_mb':p.ram_mb,'cpu_percent':p.cpu_percent,'disk_mb':p.disk_mb,'max_servers':p.max_servers,'max_ports':p.max_ports} if p else None),'status':s.status if s else 'none'}
@router.put('/users/{user_id}/plan')
def assign_plan(user_id:int, plan_id:int, request:Request, actor=Depends(require_role('Owner','Admin')),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); u=db.get(User,user_id); p=db.get(Plan,plan_id)
    if not u or not p: raise HTTPException(404,'User or plan not found')
    sub=db.query(Subscription).filter_by(user_id=u.id).first() or Subscription(user_id=u.id)
    sub.plan_id=p.id; sub.status='active'; db.add(sub); db.commit(); audit(db,actor,'plan_assign',request,details=f'user={u.id},plan={p.name}'); return {'message':'Plan assigned'}
@router.post('/plans',status_code=201)
def create_plan(payload:PlanIn,request:Request,user=Depends(require_role('Owner')),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request)
    if db.query(Plan).filter_by(name=payload.name).first(): raise HTTPException(409,'Plan exists')
    p=Plan(**payload.model_dump()); db.add(p); db.commit(); return {'id':p.id,'name':p.name}
