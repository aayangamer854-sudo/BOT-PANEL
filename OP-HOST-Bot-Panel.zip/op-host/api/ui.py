from pathlib import Path
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from config import settings
from services.security import csrf_token
from database import SessionLocal
from services.config_store import get_setting

router=APIRouter()
templates=Jinja2Templates(directory=str(settings.BASE_DIR/'templates'))

def render(request, template, **ctx):
    db=SessionLocal()
    try:
        panel_name=get_setting(db,"panel_name",settings.PANEL_NAME)
        logo_url=get_setting(db,"logo_url","")
        favicon_url=get_setting(db,"favicon_url","")
    finally: db.close()
    response=templates.TemplateResponse(request,template,{"panel_name":panel_name,"logo_url":logo_url,"favicon_url":favicon_url,**ctx})
    token=request.cookies.get('op_csrf') or csrf_token(request)
    if not request.cookies.get('op_csrf'):
        response.set_cookie('op_csrf',token,httponly=False,secure=settings.COOKIE_SECURE,samesite='lax',max_age=settings.JWT_EXPIRE_MINUTES*60,path='/')
    return response

@router.get('/',response_class=HTMLResponse)
def root(request:Request): return RedirectResponse('/dashboard.html')
@router.get('/login.html',response_class=HTMLResponse)
def login(request:Request): return render(request,'login.html')
@router.get('/register.html',response_class=HTMLResponse)
def register(request:Request): return render(request,'register.html')
@router.get('/reset-password.html',response_class=HTMLResponse)
def reset(request:Request): return render(request,'reset-password.html')
@router.get('/dashboard.html',response_class=HTMLResponse)
def dashboard(request:Request): return render(request,'dashboard.html')
@router.get('/server.html',response_class=HTMLResponse)
def server(request:Request): return render(request,'server.html')
@router.get('/console.html',response_class=HTMLResponse)
def console(request:Request): return render(request,'console.html')
@router.get('/files.html',response_class=HTMLResponse)
def files(request:Request): return render(request,'files.html')
@router.get('/settings.html',response_class=HTMLResponse)
def settings_page(request:Request): return render(request,'settings.html')
@router.get('/admin.html',response_class=HTMLResponse)
def admin(request:Request): return render(request,'admin.html')
@router.get('/users.html',response_class=HTMLResponse)
def users(request:Request): return render(request,'users.html')
