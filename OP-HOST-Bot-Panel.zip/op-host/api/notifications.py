from fastapi import APIRouter,Depends,Request
from database import get_db
from models.user import User
from models.server import Notification
from services.common import current_user
router=APIRouter()
@router.get('')
def notifications(user=Depends(current_user),db=Depends(get_db)):
    return [{'id':n.id,'title':n.title,'message':n.message,'level':n.level,'read':n.read,'created_at':n.created_at} for n in db.query(Notification).filter_by(user_id=user.id).order_by(Notification.id.desc()).limit(100).all()]
@router.post('/{notification_id}/read')
def mark(notification_id,request:Request,user=Depends(current_user),db=Depends(get_db)):
    from services.security import require_csrf
    require_csrf(request)
    n=db.query(Notification).filter_by(id=notification_id,user_id=user.id).first()
    if n: n.read=True; db.commit()
    return {'message':'Marked read'}
