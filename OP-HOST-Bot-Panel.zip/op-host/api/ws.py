from __future__ import annotations
import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from database import SessionLocal
from models.user import User
from models.server import Server, Deployment, ServerResource
from services.auth_service import decode_access_token
from services.common import can_access_server
from services.process_manager import process_manager
from services.docker_manager import docker_manager
router=APIRouter()

def get_user(ws,db):
    token=ws.cookies.get('op_access') or ws.query_params.get('token')
    if not token: return None
    try: uid=int(decode_access_token(token)['sub'])
    except: return None
    return db.get(User,uid)

@router.websocket('/ws/servers/{server_id}/console')
async def console_ws(ws:WebSocket,server_id:str):
    await ws.accept(); db=SessionLocal()
    try:
        u=get_user(ws,db); s=db.get(Server,server_id)
        if not u or not s or not u.is_active or not can_access_server(db,u,s,'console'):
            await ws.close(code=4403); return
        last=None
        while True:
            lines=docker_manager.logs(s,300) if s.runtime_mode=='docker' else process_manager.logs(db,s,300)
            data={'lines':lines,'status':s.status}
            if data!=last: await ws.send_json(data); last=data
            await asyncio.sleep(1)
    except WebSocketDisconnect: pass
    finally: db.close()

@router.websocket('/ws/servers/{server_id}/stats')
async def stats_ws(ws:WebSocket,server_id:str):
    await ws.accept(); db=SessionLocal()
    try:
        u=get_user(ws,db); s=db.get(Server,server_id)
        if not u or not s or not can_access_server(db,u,s,'view_resources'):
            await ws.close(code=4403); return
        while True:
            r=db.query(ServerResource).filter_by(server_id=s.id).first()
            await ws.send_json({'status':s.status,'cpu_percent':r.cpu_percent if r else 0,'ram_mb':r.ram_mb if r else 0,'disk_mb':r.disk_mb if r else 0,'network_rx':r.network_rx if r else 0,'network_tx':r.network_tx if r else 0,'uptime_seconds':r.uptime_seconds if r else 0,'enforcement':'docker-cgroups' if s.runtime_mode=='docker' else 'native-best-effort'})
            await asyncio.sleep(2)
    except WebSocketDisconnect: pass
    finally: db.close()

@router.websocket('/ws/servers/{server_id}/deployment')
async def deployment_ws(ws:WebSocket,server_id:str):
    await ws.accept(); db=SessionLocal()
    try:
        u=get_user(ws,db); s=db.get(Server,server_id)
        if not u or not s or not can_access_server(db,u,s,'settings'):
            await ws.close(code=4403); return
        last_id=None
        while True:
            d=db.query(Deployment).filter_by(server_id=s.id).order_by(Deployment.id.desc()).first()
            if d and d.id!=last_id:
                await ws.send_json({'id':d.id,'status':d.status,'kind':d.kind,'message':d.message}); last_id=d.id
            await asyncio.sleep(1)
    except WebSocketDisconnect: pass
    finally: db.close()
