from __future__ import annotations
import io, shutil
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, Query, Request, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from services.common import current_user, accessible_server, audit
from services.file_manager import FileManager
router=APIRouter()
class PathIn(BaseModel): path:str
class RenameIn(BaseModel): path:str; new_name:str=Field(min_length=1,max_length=255)
class MoveCopyIn(BaseModel): path:str; destination:str
class WriteIn(BaseModel): path:str; content:str

@router.get('/{server_id}/files')
def list_files(server_id:str,path:str='.',user:User=Depends(current_user),db:Session=Depends(get_db)):
 s=accessible_server(db,user,server_id,'files'); return {'path':path,'files':FileManager(s).list(path)}
@router.get('/{server_id}/file')
def read_file(server_id:str,path:str,user:User=Depends(current_user),db:Session=Depends(get_db)):
 s=accessible_server(db,user,server_id,'files'); return {'path':path,'content':FileManager(s).read_text(path)}
@router.post('/{server_id}/files')
def create_file_or_dir(server_id:str,payload:PathIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); fm=FileManager(s)
 try: (fm.mkdir(payload.path) if payload.path.endswith('/') else fm.create_file(payload.path))
 except FileExistsError: raise HTTPException(409,'Path already exists')
 audit(db,user,'file_create',request,s.id,payload.path); return {'message':'Created'}
@router.put('/{server_id}/file')
def write_file(server_id:str,payload:WriteIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); fm=FileManager(s); fm.write_text(payload.path,payload.content); audit(db,user,'file_write',request,s.id,payload.path); return {'message':'Saved'}
@router.delete('/{server_id}/files')
def delete_file(server_id:str,payload:PathIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); FileManager(s).delete(payload.path); audit(db,user,'file_delete',request,s.id,payload.path); return {'message':'Deleted'}
@router.post('/{server_id}/files/rename')
def rename_file(server_id,payload:RenameIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); FileManager(s).rename(payload.path,payload.new_name); audit(db,user,'file_rename',request,s.id,payload.path); return {'message':'Renamed'}
@router.post('/{server_id}/files/move')
def move_file(server_id,payload:MoveCopyIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); FileManager(s).move(payload.path,payload.destination); audit(db,user,'file_move',request,s.id,payload.path); return {'message':'Moved'}
@router.post('/{server_id}/files/copy')
def copy_file(server_id,payload:MoveCopyIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); FileManager(s).copy(payload.path,payload.destination); audit(db,user,'file_copy',request,s.id,payload.path); return {'message':'Copied'}
@router.post('/{server_id}/files/zip')
def zip_file(server_id,payload:PathIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); p=FileManager(s).zip(payload.path); audit(db,user,'file_zip',request,s.id,payload.path); return {'path':str(p.relative_to(Path(s.working_directory).resolve()))}
@router.post('/{server_id}/files/unzip')
def unzip_file(server_id,payload:PathIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); FileManager(s).unzip(payload.path); audit(db,user,'file_unzip',request,s.id,payload.path); return {'message':'Unzipped'}
@router.get('/{server_id}/file/download')
def download_file(server_id,path:str,user=Depends(current_user),db=Depends(get_db)):
 s=accessible_server(db,user,server_id,'files'); fm=FileManager(s); p=fm.safe(path)
 if not p.is_file(): raise HTTPException(404,'File not found')
 return FileResponse(str(p),filename=p.name)
@router.post('/{server_id}/upload')
def upload_file(server_id,file:UploadFile=File(...),path:str='.',request:Request=None,user=Depends(current_user),db:Session=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request); s=accessible_server(db,user,server_id,'files'); fm=FileManager(s); name=Path(file.filename or 'upload.bin').name; parent=fm.safe(path); parent.mkdir(parents=True,exist_ok=True); dest=parent/name
 maxb=__import__('config').settings.MAX_UPLOAD_MB*1024*1024; written=0
 with open(dest,'wb') as f:
  while chunk:=file.file.read(1024*1024):
   written+=len(chunk)
   if written>maxb: f.close(); dest.unlink(missing_ok=True); raise HTTPException(413,'Upload too large')
   f.write(chunk)
 audit(db,user,'file_upload',request,s.id,str(dest.relative_to(fm.root))); return {'message':'Uploaded','path':str(dest.relative_to(fm.root))}
@router.get('/{server_id}/files/search')
def search_files(server_id,path:str='.',q:str=Query(min_length=1,max_length=128),user=Depends(current_user),db=Depends(get_db)):
 s=accessible_server(db,user,server_id,'files'); return FileManager(s).search(q,path)
