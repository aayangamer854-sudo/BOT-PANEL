from __future__ import annotations
import asyncio, json
from fastapi import APIRouter, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import PlainTextResponse, FileResponse
from starlette.background import BackgroundTask
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from database import get_db, SessionLocal
from models.user import User
from services.common import current_user, accessible_server
from services.process_manager import process_manager
from services.docker_manager import docker_manager
from services.auth_service import decode_access_token
from services.security import require_csrf
from models.server import Server
router=APIRouter()
class CommandIn(BaseModel): command:str=Field(min_length=1,max_length=4096)
@router.get('/{server_id}/logs')
def logs(server_id,user=Depends(current_user),db=Depends(get_db)):
 s=accessible_server(db,user,server_id,'console'); return {'lines': docker_manager.logs(s) if s.runtime_mode=='docker' else process_manager.logs(db,s)}
@router.get('/{server_id}/logs/download')
def download_logs(server_id,user=Depends(current_user),db=Depends(get_db)):
    s=accessible_server(db,user,server_id,'console'); import tempfile, pathlib
    lines=docker_manager.logs(s,5000) if s.runtime_mode=='docker' else process_manager.logs(db,s,5000)
    out=pathlib.Path(tempfile.mkstemp(prefix=f'op-host-{s.id}-',suffix='.log')[1]); out.write_text('\n'.join(lines),encoding='utf-8')
    return FileResponse(str(out),filename=f'{s.name}-console.log',media_type='text/plain',background=BackgroundTask(lambda: out.unlink(missing_ok=True)))
@router.post('/{server_id}/logs/clear')
def clear_logs(server_id,request:Request,user=Depends(current_user),db=Depends(get_db)):
    require_csrf(request); s=accessible_server(db,user,server_id,'console'); db.query(__import__('models.server',fromlist=['ServerLog']).ServerLog).filter_by(server_id=s.id).delete(); db.commit(); return {'message':'Logs cleared'}
@router.get('/{server_id}/players')
def players(server_id,user=Depends(current_user),db=Depends(get_db)):
    s=accessible_server(db,user,server_id,'view_resources'); return {'supported':False,'message':'Player data is not defined for generic bot processes. Use server-specific integrations for player-aware applications.','server_id':s.id}
@router.post('/{server_id}/command')
def command(server_id,payload:CommandIn,request:Request,user=Depends(current_user),db=Depends(get_db)):
 require_csrf(request); s=accessible_server(db,user,server_id,'console')
 if s.runtime_mode=='docker':
  if not docker_manager.available(): raise HTTPException(409,'Docker unavailable')
  docker_manager.send(s,payload.command)
 else:
  try: process_manager.send(s,payload.command)
  except Exception as e: raise HTTPException(409,str(e))
 return {'message':'Command sent'}

def ws_user(websocket,db):
 token=websocket.cookies.get('op_access')
 if not token: token=websocket.query_params.get('token')
 if not token: return None
 try: uid=int(decode_access_token(token)['sub'])
 except: return None
 return db.get(User,uid)

@router.websocket('/{server_id}/ws/console')
async def ws_console(websocket:WebSocket,server_id:str):
 await websocket.accept(); db=SessionLocal()
 try:
  user=ws_user(websocket,db); s=db.get(Server,server_id)
  if not user or not user.is_active or not s or not __import__('services.common',fromlist=['can_access_server']).can_access_server(db,user,s,'console'):
   await websocket.close(code=4403); return
  last=''
  while True:
   lines=docker_manager.logs(s,200) if s.runtime_mode=='docker' else process_manager.logs(db,s,200)
   payload='\n'.join(lines)
   if payload!=last: await websocket.send_json({'lines':lines,'status':s.status}); last=payload
   await asyncio.sleep(1)
 except WebSocketDisconnect: pass
 finally: db.close()
