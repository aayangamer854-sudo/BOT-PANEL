from __future__ import annotations
import platform, shutil, os, time, socket, psutil
from fastapi import APIRouter, Depends, Request, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from models.server import Server, Port, Settings as SettingModel
from models.activity import ActivityLog
from services.common import require_role, audit
from config import settings
router=APIRouter()
class SettingIn(BaseModel): key:str; value:str
@router.get('/overview')
def overview(user=Depends(require_role('Owner','Admin','Staff')),db=Depends(get_db)):
 du=shutil.disk_usage(settings.BASE_DIR); vm=psutil.virtual_memory(); return {'panel_version':settings.VERSION,'hostname':socket.gethostname(),'os':platform.platform(),'kernel':platform.release(),'python':platform.python_version(),'cpu_count':psutil.cpu_count(),'cpu_percent':psutil.cpu_percent(interval=0.1),'ram_mb':vm.total/1024/1024,'ram_used_mb':vm.used/1024/1024,'disk_gb':du.total/1024**3,'disk_used_gb':du.used/1024**3,'uptime_seconds':int(time.time()-psutil.boot_time()),'total_users':db.query(User).count(),'total_servers':db.query(Server).count(),'running_servers':db.query(Server).filter(Server.status=='RUNNING').count()}
@router.get('/settings')
def get_settings(user=Depends(require_role('Owner','Admin')),db=Depends(get_db)):
 rows=db.query(SettingModel).all(); data={r.key:r.value for r in rows}; data.setdefault('panel_name',settings.PANEL_NAME); data.setdefault('registration',str(settings.ALLOW_REGISTRATION).lower()); data.setdefault('port_range',f'{settings.PORT_RANGE_START}-{settings.PORT_RANGE_END}'); data.setdefault('default_cpu_percent','100'); data.setdefault('default_ram_mb','512'); data.setdefault('default_disk_mb','2048'); data.setdefault('logo_url',''); data.setdefault('favicon_url',''); data.setdefault('theme','dark'); data.setdefault('maintenance_mode','false'); return data
@router.put('/settings')
def put_setting(payload:SettingIn,request:Request,user=Depends(require_role('Owner')),db=Depends(get_db)):
 from services.security import require_csrf; require_csrf(request)
 if payload.key in {'secret_key','jwt_secret','session_secret'}: raise HTTPException(400,'Secrets are configured in .env only')
 row=db.query(SettingModel).filter_by(key=payload.key).first() or SettingModel(key=payload.key); row.value=payload.value; db.add(row); db.commit(); audit(db,user,'settings_change',request,details=payload.key); return {'message':'Setting saved'}
@router.get('/ports')
def ports(user=Depends(require_role('Owner','Admin','Staff')),db=Depends(get_db)):
 return {'range':[settings.PORT_RANGE_START,settings.PORT_RANGE_END],'allocations':[{'public_port':p.public_port,'internal_port':p.internal_port,'server_id':p.server_id,'protocol':p.protocol,'active':p.is_active} for p in db.query(Port).order_by(Port.public_port).all()]}
@router.get('/activity')
def activity(user=Depends(require_role('Owner','Admin','Staff')),db=Depends(get_db)):
 rows=db.query(ActivityLog).order_by(ActivityLog.id.desc()).limit(500).all(); return [{'id':r.id,'user_id':r.user_id,'server_id':r.server_id,'action':r.action,'details':r.details,'ip_address':r.ip_address,'created_at':r.created_at} for r in rows]


@router.get('/discord')
def discord_get(user=Depends(require_role('Owner','Admin')),db=Depends(get_db)):
    from services.config_store import get_setting
    return {'configured':bool(settings.DISCORD_WEBHOOK_URL),'webhook_preview':('••••'+settings.DISCORD_WEBHOOK_URL[-6:] if settings.DISCORD_WEBHOOK_URL else ''),'enabled':str(get_setting(db,'discord_enabled','true')).lower()=='true'}
class DiscordSetting(BaseModel): enabled:bool
@router.put('/discord')
def discord_put(payload:DiscordSetting,request:Request,user=Depends(require_role('Owner')),db=Depends(get_db)):
    from services.security import require_csrf; require_csrf(request); from services.config_store import set_setting
    set_setting(db,'discord_enabled',str(payload.enabled).lower()); audit(db,user,'discord_settings',request); return {'message':'Discord notification preference saved','configured':bool(settings.DISCORD_WEBHOOK_URL)}
