import os, sys, time, tempfile
from pathlib import Path

TEST_DB=Path('/tmp/op_host_panel_test.db')
try: TEST_DB.unlink()
except FileNotFoundError: pass
os.environ['DATABASE_URL']=f'sqlite:///{TEST_DB}'
os.environ['BOOTSTRAP_ADMIN_USERNAME']='admin'
os.environ['BOOTSTRAP_ADMIN_EMAIL']='admin@test.local'
os.environ['BOOTSTRAP_ADMIN_PASSWORD']='Admin1234'
os.environ['ALLOW_NATIVE_USER_BOTS']='true'
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient
from app import app
from database import SessionLocal
from models.user import User
from services.cron import next_run


def get_csrf(client):
    return client.cookies.get('op_csrf')

def json_headers(client):
    return {'X-CSRF-Token': get_csrf(client)}

def test_cron():
    from datetime import datetime
    got=next_run('*/15 * * * *',datetime(2026,1,1,0,1))
    assert got.minute==15

def test_full_panel_flow():
    with TestClient(app) as c:
        r=c.get('/login.html'); assert r.status_code==200
        r=c.post('/api/auth/login',json={'login':'admin','password':'Admin1234'}); assert r.status_code==200, r.text
        csrf=json_headers(c)
        r=c.get('/api/auth/me'); assert r.status_code==200 and r.json()['username']=='admin'
        r=c.post('/api/servers',headers=csrf,json={
            'name':'Test Bot','runtime':'Python','version':'3.13','startup_command':'python3 -c "print(\\"hello\\")"',
            'runtime_mode':'native','cpu_limit':100,'ram_limit_mb':256,'disk_limit_mb':1024,'process_limit':16,
            'auto_restart':False,'auto_start':False,'public_port':None,'internal_port':8000
        })
        assert r.status_code==201, r.text
        sid=r.json()['id']
        root=Path(r.json()['working_directory'])
        assert root.exists()
        r=c.get(f'/api/servers/{sid}/files'); assert r.status_code==200
        r=c.post(f'/api/servers/{sid}/files',headers=csrf,json={'path':'main.py'}); assert r.status_code==200
        r=c.put(f'/api/servers/{sid}/file',headers=csrf,json={'path':'main.py','content':'print("hello")'}); assert r.status_code==200
        r=c.get(f'/api/servers/{sid}/file',params={'path':'main.py'}); assert r.json()['content']=='print("hello")'
        r=c.get(f'/api/servers/{sid}/files',params={'path':'../../'}); assert r.status_code in (400,404)
        r=c.post(f'/api/servers/{sid}/environment',headers=csrf,json={'name':'TOKEN','value':'secret','is_secret':True}); assert r.status_code==200
        r=c.get(f'/api/servers/{sid}/environment'); assert r.json()[0]['value']=='********'
        r=c.post(f'/api/servers/{sid}/start',headers=csrf); assert r.status_code==200, r.text
        time.sleep(1)
        r=c.get(f'/api/servers/{sid}/logs'); assert r.status_code==200
        r=c.get(f'/api/servers/{sid}/resources'); assert r.status_code==200
        r=c.post(f'/api/servers/{sid}/stop',headers=csrf); assert r.status_code==200
        r=c.post(f'/api/servers/{sid}/logs/clear',headers=csrf); assert r.status_code==200
        r=c.get(f'/api/servers/{sid}/logs/download'); assert r.status_code==200
        with c.websocket_connect(f'/ws/servers/{sid}/console') as ws:
            msg=ws.receive_json(); assert 'status' in msg and 'lines' in msg
        with c.websocket_connect(f'/ws/servers/{sid}/stats') as ws:
            msg=ws.receive_json(); assert 'cpu_percent' in msg
        # Deployment WebSocket is verified by route registration/source inspection; it waits for a deployment event by design.
        r=c.get(f'/api/servers/{sid}/players'); assert r.status_code==200 and r.json()['supported'] is False
        r=c.post('/api/keys',headers=csrf,json={'name':'test-key'}); assert r.status_code==201
        token=r.json()['token']
        r=c.get('/api/servers',headers={'Authorization':f'Bearer {token}'}); assert r.status_code==200
        r=c.delete(f'/api/servers/{sid}',headers=csrf); assert r.status_code==200
        assert not root.exists()
